import { bundle } from "@remotion/bundler";
import {
  selectComposition,
  renderMedia,
  renderStill,
} from "@remotion/renderer";
import { access, mkdir } from "node:fs/promises";
import path from "node:path";
const intro = process.argv.includes("--intro");
if (!intro) {
  for (const slug of ["zkx-main", "etp", "bk", "nero", "zkx-impact"]) {
    try {
      await access(`public/vertical/captures/${slug}.mp4`);
    } catch {
      throw new Error(
        `Capture réelle manquante : ${slug}. Fournir une capture ou exécuter scripts/capture-sites.mjs après autorisation réseau.`,
      );
    }
  }
}
await mkdir("out", { recursive: true });
const serveUrl = await bundle({
  entryPoint: path.resolve("src/index.ts"),
  enableCaching: true,
});
const browserExecutable = process.env.CHROME_PATH || "/usr/bin/chromium";
const chromiumOptions = { gl: "swangle" };
const composition = await selectComposition({
  serveUrl,
  id: "ZKX-Vertical-Portfolio",
  browserExecutable,
  chromiumOptions,
});
if (process.argv.includes("--stills") || intro) {
  for (const frame of intro
    ? [90, 990]
    : [90, 240, 390, 505, 615, 725, 855, 990]) {
    await renderStill({
      serveUrl,
      composition,
      frame,
      browserExecutable,
      chromiumOptions,
      output: `out/vertical-${frame}.png`,
      imageFormat: "png",
    });
    console.log(`Image vérifiée : ${frame}`);
  }
} else {
  let last = -1;
  const smoke = process.argv.includes("--smoke");
  await renderMedia({
    serveUrl,
    composition,
    browserExecutable,
    chromiumOptions,
    outputLocation: smoke
      ? "out/ZKX-Portfolio-Smoke.mp4"
      : "out/ZKX-Portfolio-Vertical-35s.mp4",
    frameRange: smoke ? [150, 179] : undefined,
    codec: "h264",
    crf: 17,
    pixelFormat: "yuv420p",
    audioCodec: "aac",
    audioBitrate: "256k",
    concurrency: 2,
    disableSharedMemoryCapture: true,
    imageFormat: "jpeg",
    jpegQuality: 95,
    onProgress: ({ progress }) => {
      const p = Math.floor(progress * 100);
      if (p >= last + 5) {
        console.log(`Rendu : ${p} %`);
        last = p;
      }
    },
  });
  console.log(
    smoke
      ? "Test terminé : out/ZKX-Portfolio-Smoke.mp4"
      : "Export terminé : out/ZKX-Portfolio-Vertical-35s.mp4",
  );
}
