import React, { useLayoutEffect, useMemo, useState, useCallback } from "react";
import { useThree } from "@react-three/fiber";
import { RoundedBox, Text3D, Center } from "@react-three/drei";
import {
  EffectComposer,
  Bloom,
  DepthOfField,
  FXAA,
} from "@react-three/postprocessing";
import { staticFile, Sequence } from "remotion";
import { Video } from "@remotion/media";
import * as THREE from "three";
import { Lighting, Chrome, Ring, Dust } from "../zkx/World";
import { logoPolygons } from "../zkx/brand";

const ease = (n: number) => {
  const p = Math.max(0, Math.min(1, n));
  return p * p * (3 - 2 * p);
};
const lerp = THREE.MathUtils.lerp;

const Brand: React.FC<{ time: number; outro?: boolean }> = ({
  time,
  outro = false,
}) => {
  const geometry = useMemo(
    () =>
      logoPolygons.map((poly) => {
        const shape = new THREE.Shape();
        poly.forEach(([x, y], i) => {
          if (i === 0) shape.moveTo((x - 192) / 54, (49 - y) / 54);
          else shape.lineTo((x - 192) / 54, (49 - y) / 54);
        });
        shape.closePath();
        return new THREE.ExtrudeGeometry(shape, {
          depth: 0.22,
          bevelEnabled: true,
          bevelSize: 0.035,
          bevelThickness: 0.055,
          bevelSegments: 4,
          steps: 1,
        });
      }),
    [],
  );
  const p = ease(time / (outro ? 0.9 : 2.4));
  return (
    <group
      position={[0, outro ? 1.1 : 0.4, 0]}
      scale={0.5}
      rotation={[0.05, outro ? -0.06 : lerp(-0.65, 0.06, p), -0.025 * (1 - p)]}
    >
      {geometry.map((g, i) => (
        <mesh
          key={i}
          geometry={g}
          position={[
            (i - 2) * (1 - p) * 2.7,
            Math.sin(i * 2) * (1 - p) * 1.5,
            -(1 - p) * (i % 2) * 2,
          ]}
          rotation={[0, (1 - p) * (i - 2) * 0.2, 0]}
        >
          <Chrome roughness={0.16} />
        </mesh>
      ))}
    </group>
  );
};

const MovingScreen: React.FC<{ slug: string }> = ({ slug }) => {
  const imageHeight = slug.startsWith("zkx") ? 928 : 824;
  const { advance } = useThree();
  const [canvas] = useState(() => {
    const c = document.createElement("canvas");
    c.width = 512;
    c.height = imageHeight;
    return c;
  });
  const ctx = useMemo(() => canvas.getContext("2d")!, [canvas]);
  const texture = useMemo(() => {
    const t = new THREE.CanvasTexture(canvas);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [canvas]);
  const mask = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = 512;
    c.height = imageHeight;
    const x = c.getContext("2d")!;
    x.fillStyle = "black";
    x.fillRect(0, 0, 512, imageHeight);
    x.fillStyle = "white";
    x.beginPath();
    x.roundRect(0, 0, 512, imageHeight, 28);
    x.fill();
    return new THREE.CanvasTexture(c);
  }, [imageHeight]);
  const onFrame = useCallback(
    (frame: CanvasImageSource) => {
      ctx.drawImage(frame, 0, 0, 512, imageHeight);
      texture.needsUpdate = true;
      advance(performance.now());
    },
    [ctx, texture, advance, imageHeight],
  );
  return (
    <>
      <Video
        src={staticFile(`vertical/captures/${slug}.mp4`)}
        headless
        muted
        onVideoFrame={onFrame}
      />
      <mesh position={[0, 0, 0.183]}>
        <planeGeometry args={[2.5, (2.5 * imageHeight) / 512]} />
        <meshBasicMaterial
          map={texture}
          alphaMap={mask}
          transparent
          toneMapped={false}
        />
      </mesh>
    </>
  );
};
const Screen: React.FC<{ slug: string; from: number }> = ({ slug, from }) => (
  <Sequence from={from} layout="none">
    <MovingScreen slug={slug} />
  </Sequence>
);

const Device: React.FC<{
  slug: string;
  from: number;
  time: number;
  glass?: boolean;
  scale?: number;
}> = ({ slug, from, time, glass = false, scale = 1 }) => {
  const angle = Math.sin(time * 0.38) * 0.13;
  const displayHeight = (2.5 * (slug.startsWith("zkx") ? 928 : 824)) / 512;
  return (
    <group
      scale={scale}
      rotation={[
        0.025 + Math.sin(time * 0.3) * 0.025,
        angle,
        -0.018 + Math.sin(time * 0.35) * 0.012,
      ]}
      position={[Math.sin(time * 0.23) * 0.12, Math.sin(time * 0.6) * 0.09, 0]}
    >
      <RoundedBox
        args={[2.72, displayHeight + 0.22, glass ? 0.12 : 0.24]}
        radius={glass ? 0.09 : 0.2}
        smoothness={4}
      >
        <Chrome roughness={0.19} />
      </RoundedBox>
      <RoundedBox
        args={[2.62, displayHeight + 0.12, 0.06]}
        position={[0, 0, 0.145]}
        radius={0.17}
        smoothness={4}
      >
        <meshStandardMaterial
          color="#030405"
          roughness={0.24}
          metalness={0.5}
        />
      </RoundedBox>
      <Screen slug={slug} from={from} />
      {!glass ? (
        <>
          <RoundedBox
            args={[0.49, 0.095, 0.027]}
            radius={0.045}
            smoothness={3}
            position={[0, 2.14, 0.202]}
          >
            <meshStandardMaterial
              color="#020204"
              roughness={0.22}
              metalness={0.65}
            />
          </RoundedBox>
          <mesh position={[0.16, 2.138, 0.223]}>
            <sphereGeometry args={[0.025, 12, 8]} />
            <meshStandardMaterial
              color="#1c2434"
              metalness={0.7}
              roughness={0.1}
            />
          </mesh>
          <RoundedBox
            args={[0.045, 0.55, 0.09]}
            radius={0.02}
            position={[-1.38, 1.05, 0]}
          >
            <Chrome />
          </RoundedBox>
          <RoundedBox
            args={[0.045, 0.37, 0.09]}
            radius={0.02}
            position={[1.38, 0.8, 0]}
          >
            <Chrome />
          </RoundedBox>
        </>
      ) : null}
    </group>
  );
};

const ChromeWord: React.FC<{
  children: string;
  position: [number, number, number];
  scale?: number;
}> = ({ children, position, scale = 0.2 }) => (
  <group position={position} scale={scale}>
    <Center>
      <Text3D
        font={staticFile("vertical/typeface.json")}
        size={1}
        height={0.065}
        bevelEnabled
        bevelSize={0.012}
        bevelThickness={0.008}
        bevelSegments={2}
        curveSegments={6}
      >
        <Chrome roughness={0.23} />
        {children}
      </Text3D>
    </Center>
  </group>
);

const Camera: React.FC<{ time: number }> = ({ time: t }) => {
  const { camera, scene } = useThree();
  useLayoutEffect(() => {
    let p: [number, number, number] = [0, 0, 13.3];
    let target: [number, number, number] = [0, 0, 0];
    if (t < 5) {
      const q = ease(t / 5);
      p = [lerp(-2.1, 0.2, q), lerp(0.8, 0.2, q), lerp(14.6, 11.8, q)];
      target = [0, 0.3, 0];
      if (t > 4.6) p[2] -= ease((t - 4.6) / 0.4) * 3;
    } else if (t < 15) {
      const q = ease((t - 5) / 10);
      p = [lerp(-1.2, 0.85, q), lerp(0.3, 0.05, q), lerp(13.3, 12.4, q)];
      target = [0, 0.05, 0];
    } else if (t < 26) {
      const start = t < 560 / 30 ? 15 : t < 670 / 30 ? 560 / 30 : 670 / 30;
      const q = ease((t - start) / 3.67);
      p = [
        lerp(t < 560 / 30 ? 1.25 : -1.1, 0.15, q),
        lerp(0.6, 0.1, q),
        lerp(14.1, 13.2, q),
      ];
    } else if (t < 31) {
      const q = ease((t - 26) / 5);
      p = [lerp(0.7, -0.6, q), lerp(0.35, 0.15, q), lerp(14, 13.1, q)];
      target = [0, -0.05, 0];
    } else {
      const q = ease((t - 31) / 4);
      p = [lerp(-0.7, 0, q), 0.25, lerp(13.7, 12.8, q)];
      target = [0, 0.5, 0];
    }
    camera.position.set(...p);
    camera.lookAt(...target);
    camera.updateProjectionMatrix();
    scene.environmentRotation.set(0, Math.sin(t * 0.3) * 0.27, 0);
  }, [camera, scene, t]);
  return null;
};

export const VerticalWorld: React.FC<{ time: number }> = ({ time: t }) => {
  const main = t >= 5 && t < 15;
  const portfolio = t >= 15 && t < 26;
  const impact = t >= 26 && t < 31;
  const slug = t < 560 / 30 ? "etp" : t < 670 / 30 ? "bk" : "nero";
  const start = t < 560 / 30 ? 15 : t < 670 / 30 ? 560 / 30 : 670 / 30;
  const keyword = main
    ? t < 8.4
      ? "WEB DESIGN"
      : t < 11.7
        ? "DIGITAL PRESENCE"
        : "ONLINE VISIBILITY"
    : impact
      ? t < 27
        ? "VISIBILITY"
        : t < 28
          ? "CREDIBILITY"
          : t < 29
            ? "BRAND IMAGE"
            : t < 30
              ? "PERFORMANCE"
              : "GROWTH"
      : "";
  return (
    <>
      <color attach="background" args={["#020204"]} />
      <fog attach="fog" args={["#020204", 22, 55]} />
      <Lighting />
      <Camera time={t} />
      <Dust />

      {t < 5 ? (
        <>
          <Brand time={t} />
          <Ring
            radius={3.4}
            tube={0.023}
            position={[0, 0.4, -2]}
            rotation={[0.4, 0.4, t * 0.09]}
          />
          <Ring
            radius={3.6}
            tube={0.008}
            position={[0, 0.4, -2]}
            rotation={[0.4, 0.4, t * 0.09]}
          />
        </>
      ) : null}
      {main ? (
        <>
          <Device slug="zkx-main" from={150} time={t - 5} scale={1.02} />
          <Ring
            radius={3.5}
            tube={0.025}
            position={[0, 0, -3]}
            rotation={[0.4, 0.7, (t - 5) * 0.04]}
          />
          <Ring
            radius={3.68}
            tube={0.007}
            position={[0, 0, -3]}
            rotation={[0.4, 0.7, (t - 5) * 0.04]}
          />
        </>
      ) : null}
      {portfolio ? (
        <group position={[0, 0, 0]}>
          <Device
            slug={slug}
            from={slug === "etp" ? 450 : slug === "bk" ? 560 : 670}
            time={t - start}
            glass
            scale={0.94}
          />
          <Ring
            radius={3.3}
            tube={0.045}
            position={[0, 0, -3.2]}
            rotation={[0.3, -0.6, (t - start) * 0.07]}
          />
          <mesh
            position={[-2.1, -2.5, -1]}
            rotation={[t * 0.06, t * 0.16, 0.3]}
          >
            <octahedronGeometry args={[0.4, 0]} />
            <Chrome />
          </mesh>
        </group>
      ) : null}
      {impact ? (
        <>
          <group position={[0, -0.35, -0.4]}>
            <Device slug="zkx-impact" from={780} time={t} scale={0.88} />
          </group>
          <Ring
            radius={3.3}
            tube={0.016}
            position={[0, -0.3, -2]}
            rotation={[0.5, 0.8, t * 0.06]}
          />
          <Ring
            radius={3.7}
            tube={0.008}
            position={[0, -0.3, -2.3]}
            rotation={[0.3, 0.4, t * 0.04]}
          />
        </>
      ) : null}
      {main || impact ? (
        <ChromeWord
          position={[0, impact ? -2.95 : 3.25, 0.9]}
          scale={keyword.length > 15 ? 0.18 : 0.22}
        >
          {keyword}
        </ChromeWord>
      ) : null}
      {t >= 31 ? (
        <>
          <Brand time={t - 31} outro />
          <Ring
            radius={3.5}
            tube={0.028}
            position={[0, 0.8, -2]}
            rotation={[0.3, 0.2, (t - 31) * 0.025]}
          />
        </>
      ) : null}
      <EffectComposer multisampling={0}>
        <Bloom
          luminanceThreshold={1.7}
          intensity={0.14}
          mipmapBlur={false}
          resolutionScale={0.25}
        />
        <DepthOfField
          focusDistance={0.21}
          focalLength={0.28}
          bokehScale={0.2}
          resolutionScale={0.25}
        />
        <FXAA />
      </EffectComposer>
    </>
  );
};
