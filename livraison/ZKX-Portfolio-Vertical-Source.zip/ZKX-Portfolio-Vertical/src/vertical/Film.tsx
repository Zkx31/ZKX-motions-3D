import React from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  interpolate,
  Easing,
  staticFile,
  useCurrentFrame,
} from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { VerticalWorld } from "./World";
const curve = Easing.bezier(0.22, 1, 0.36, 1);
const ramp = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: curve,
  });
const TextIn: React.FC<{
  f: number;
  from: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ f, from, children, style }) => {
  const p = ramp(f, from, from + 24);
  return <div style={{ ...style, opacity: p }}>{children}</div>;
};
const small: React.CSSProperties = {
  fontFamily: "Arial,Helvetica,sans-serif",
  fontSize: 18,
  letterSpacing: 4,
  color: "#abb1bc",
};
export const VerticalFilm: React.FC = () => {
  const f = useCurrentFrame(),
    t = f / 30;
  const isMain = t >= 5 && t < 15,
    portfolio = t >= 15 && t < 26,
    impact = t >= 26 && t < 31;
  const index = t < 560 / 30 ? 0 : t < 670 / 30 ? 1 : 2;
  const project = ["ETP PEINTURE", "B.K MULTISERVICES", "NERO TOULOUSE"][index];
  const desc = ["SITE VITRINE", "WEB DESIGN", "DIGITAL EXPERIENCE"][index];
  const from = [450, 560, 670][index];
  const cuts = [150, 450, 560, 670, 780, 930];
  const dip = Math.max(
    ...cuts.map((c) =>
      interpolate(f, [c - 5, c, c + 7], [0, 0.96, 0], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      }),
    ),
  );
  const fadeIn = 1 - ramp(f, 0, 26),
    fadeOut = ramp(f, 1034, 1049);
  return (
    <AbsoluteFill
      style={{
        background: "#020204",
        color: "#f3f4f7",
        fontFamily: "Arial,Helvetica,sans-serif",
      }}
    >
      <Audio src={staticFile("vertical/score.wav")} volume={0.8} />
      <ThreeCanvas
        width={1080}
        height={1920}
        dpr={0.6666666667}
        camera={{ fov: 39, near: 0.1, far: 60 }}
        gl={{
          alpha: false,
          antialias: false,
          powerPreference: "high-performance",
        }}
      >
        <VerticalWorld time={t} />
      </ThreeCanvas>
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse at 50% 48%,transparent 36%,rgba(0,0,0,.55) 100%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          top: 158,
          left: 94,
          right: 160,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          opacity: ramp(f, 15, 40),
        }}
      >
        <span style={{ fontSize: 19, letterSpacing: 4, fontWeight: 600 }}>
          ZKX{" "}
          <span
            style={{
              fontSize: 12,
              fontWeight: 400,
              letterSpacing: 3,
              marginLeft: 10,
              color: "#a0a7b3",
            }}
          >
            DIGITAL LAB
          </span>
        </span>
        <span style={{ ...small, fontSize: 12, letterSpacing: 2 }}>
          STUDIO DIGITAL
        </span>
      </div>
      {t < 5 ? (
        <>
          <div
            style={{
              position: "absolute",
              top: 438,
              left: 100,
              right: 100,
              textAlign: "center",
            }}
          >
            <TextIn f={f} from={22} style={small}>
              UNE NOUVELLE DIMENSION
            </TextIn>
          </div>
          <div
            style={{
              position: "absolute",
              top: 1120,
              left: 90,
              right: 90,
              textAlign: "center",
            }}
          >
            <TextIn f={f} from={35} style={{ fontSize: 30, letterSpacing: 12 }}>
              DIGITAL LAB
            </TextIn>
            <TextIn
              f={f}
              from={58}
              style={{
                ...small,
                fontSize: 17,
                letterSpacing: 3.5,
                marginTop: 66,
              }}
            >
              THE FUTURE OF WEB DESIGN
            </TextIn>
          </div>
        </>
      ) : null}
      {isMain ? (
        <>
          <div
            style={{
              position: "absolute",
              top: 1575,
              left: 94,
              right: 160,
              textAlign: "center",
            }}
          >
            <TextIn
              f={f}
              from={165}
              style={{ fontSize: 33, letterSpacing: -0.6 }}
            >
              Le site qui parle pour vous.
            </TextIn>
            <TextIn
              f={f}
              from={180}
              style={{
                fontSize: 17,
                color: "#8d96a5",
                letterSpacing: 2,
                marginTop: 24,
              }}
            >
              ZKX DIGITAL LAB / CRÉATION WEB
            </TextIn>
          </div>
        </>
      ) : null}
      {portfolio ? (
        <>
          <div
            style={{
              position: "absolute",
              top: 256,
              left: 94,
              right: 160,
              textAlign: "center",
            }}
          >
            <TextIn
              f={f}
              from={from + 4}
              style={{ ...small, fontSize: 14, letterSpacing: 3 }}
            >
              RÉALISATION ZKX DIGITAL LAB / 0{index + 1}
            </TextIn>
            <TextIn
              f={f}
              from={from + 10}
              style={{ fontSize: 39, letterSpacing: -1, marginTop: 25 }}
            >
              {project}
            </TextIn>
          </div>
          <div
            style={{
              position: "absolute",
              top: 1558,
              left: 94,
              right: 160,
              textAlign: "center",
            }}
          >
            <TextIn
              f={f}
              from={from + 14}
              style={{ ...small, fontSize: 21, letterSpacing: 4 }}
            >
              {desc}
            </TextIn>
            <TextIn
              f={f}
              from={from + 20}
              style={{ fontSize: 17, color: "#858e9c", marginTop: 24 }}
            >
              Un extrait de notre portfolio.
            </TextIn>
          </div>
        </>
      ) : null}
      {impact ? (
        <div
          style={{
            position: "absolute",
            top: 230,
            left: 94,
            right: 160,
            textAlign: "center",
          }}
        >
          <TextIn
            f={f}
            from={786}
            style={{ fontSize: 47, lineHeight: 1.12, letterSpacing: -1.5 }}
          >
            VOTRE PRÉSENCE DIGITALE
            <br />
            FAIT LA DIFFÉRENCE.
          </TextIn>
        </div>
      ) : null}
      {t >= 31 ? (
        <>
          <div
            style={{
              position: "absolute",
              left: 94,
              right: 94,
              top: 1055,
              textAlign: "center",
            }}
          >
            <TextIn
              f={f}
              from={938}
              style={{ fontSize: 31, letterSpacing: 11 }}
            >
              DIGITAL LAB
            </TextIn>
            <TextIn
              f={f}
              from={949}
              style={{
                fontSize: 37,
                lineHeight: 1.3,
                letterSpacing: -0.5,
                marginTop: 66,
              }}
            >
              DES SITES MODERNES
              <br />
              POUR DES ENTREPRISES
              <br />
              AMBITIEUSES.
            </TextIn>
            <TextIn
              f={f}
              from={968}
              style={{
                fontSize: 20,
                letterSpacing: 0.6,
                color: "#bcc2cc",
                marginTop: 58,
              }}
            >
              zkx.digital-lab-9d1.workers.dev
            </TextIn>
          </div>
        </>
      ) : null}
      <div
        style={{
          position: "absolute",
          left: 94,
          right: 160,
          bottom: 230,
          opacity: ramp(f, 20, 50) * 0.7,
        }}
      >
        <div style={{ height: 1, background: "#343943" }}>
          <div
            style={{
              height: 1,
              width: `${(f / 1049) * 100}%`,
              background: "#cbd0d9",
            }}
          />
        </div>
        <div
          style={{
            fontSize: 11,
            letterSpacing: 3,
            color: "#828c9b",
            marginTop: 19,
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <span>ZKX / DIGITAL LAB</span>
          <span>DESIGN · PRÉSENCE · IMPACT</span>
        </div>
      </div>
      <AbsoluteFill style={{ opacity: 0.018, pointerEvents: "none" }}>
        <Img
          src={staticFile("zkx/grain.png")}
          style={{ width: "100%", height: "100%" }}
        />
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          background: "#020204",
          opacity: Math.max(dip, fadeIn, fadeOut),
        }}
      />
    </AbsoluteFill>
  );
};
