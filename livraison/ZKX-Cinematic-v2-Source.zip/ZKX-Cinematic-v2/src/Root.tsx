import { Composition } from "remotion";
import { ZkxFilm } from "./zkx/Film";
import { VerticalFilm } from "./vertical/Film";

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="ZKX-Vertical-Portfolio"
      component={VerticalFilm}
      durationInFrames={1050}
      fps={30}
      width={1080}
      height={1920}
    />
    <Composition
      id="ZKX-Digital-Lab-FR"
      component={ZkxFilm}
      durationInFrames={1050}
      fps={30}
      width={1920}
      height={1080}
    />
  </>
);
