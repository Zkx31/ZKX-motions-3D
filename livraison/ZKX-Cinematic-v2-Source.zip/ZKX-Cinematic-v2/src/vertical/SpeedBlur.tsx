import React, { useMemo, useLayoutEffect, useEffect } from "react";
import { Effect, BlendFunction, EffectAttribute } from "postprocessing";
import { Uniform, Vector2 } from "three";
import { transitionAt } from "./motion";
const shader = `
uniform vec2 blurDirection;
uniform float zoomAmount;
void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
 vec2 d = blurDirection + (uv-vec2(0.5))*zoomAmount;
 if (dot(d,d) < 0.00000001) { outputColor=inputColor; return; }
 vec4 color=inputColor*0.4;
 color+=texture2D(inputBuffer,clamp(uv+d,vec2(0.),vec2(1.)))*0.2;
 color+=texture2D(inputBuffer,clamp(uv-d,vec2(0.),vec2(1.)))*0.2;
 color+=texture2D(inputBuffer,clamp(uv+d*2.,vec2(0.),vec2(1.)))*0.1;
 color+=texture2D(inputBuffer,clamp(uv-d*2.,vec2(0.),vec2(1.)))*0.1;
 outputColor=color;
}`;
/** Spatial speed blur for fast transitions, not a claim of temporal motion blur. */
export const SpeedBlur: React.FC<{ frame: number }> = ({ frame }) => {
  const effect = useMemo(
    () =>
      new Effect("ZkxSpeedBlur", shader, {
        blendFunction: BlendFunction.NORMAL,
        attributes: EffectAttribute.CONVOLUTION,
        uniforms: new Map<string, Uniform>([
          ["blurDirection", new Uniform(new Vector2())],
          ["zoomAmount", new Uniform(0)],
        ]),
      }),
    [],
  );
  useLayoutEffect(() => {
    const p = transitionAt(frame);
    (effect.uniforms.get("blurDirection")!.value as Vector2).set(
      p.zoom ? 0 : p.strength * 0.018,
      p.zoom ? 0 : p.strength * 0.002,
    );
    effect.uniforms.get("zoomAmount")!.value = p.zoom ? p.strength * 0.055 : 0;
  }, [effect, frame]);
  useEffect(() => () => effect.dispose(), [effect]);
  return <primitive object={effect} dispose={null} />;
};
