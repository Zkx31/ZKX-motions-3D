import React, { useLayoutEffect, useMemo, useState, useCallback } from "react";
import { useThree, useLoader } from "@react-three/fiber";
import { RoundedBox, Text3D, Center } from "@react-three/drei";
import {
  EffectComposer,
  Bloom,
  DepthOfField,
  FXAA,
} from "@react-three/postprocessing";
import { staticFile, Sequence } from "remotion";
import { Video } from "@remotion/media";
import * as THREE from "three";
import { Lighting, Chrome, Ring, Dust } from "../zkx/World";
import { logoPolygons } from "../zkx/brand";
import {
  cameraAt,
  focusAt,
  deviceAt,
  ease as frameEase,
  mix as frameMix,
  transitionAt,
  Vec3,
} from "./motion";
import { SpeedBlur } from "./SpeedBlur";

const ease = (n: number) => {
  const p = Math.max(0, Math.min(1, n));
  return p * p * (3 - 2 * p);
};
const lerp = THREE.MathUtils.lerp;

const Brand: React.FC<{ time: number; outro?: boolean }> = ({
  time,
  outro = false,
}) => {
  const geometry = useMemo(
    () =>
      logoPolygons.map((poly) => {
        const shape = new THREE.Shape();
        poly.forEach(([x, y], i) => {
          if (i === 0) shape.moveTo((x - 192) / 54, (49 - y) / 54);
          else shape.lineTo((x - 192) / 54, (49 - y) / 54);
        });
        shape.closePath();
        return new THREE.ExtrudeGeometry(shape, {
          depth: 0.22,
          bevelEnabled: true,
          bevelSize: 0.035,
          bevelThickness: 0.055,
          bevelSegments: 4,
          steps: 1,
        });
      }),
    [],
  );
  const p = ease(time / (outro ? 0.9 : 2.4));
  return (
    <group
      position={[0, outro ? 1.1 : 0.4, 0]}
      scale={0.5}
      rotation={[0.05, outro ? -0.06 : lerp(-0.65, 0.06, p), -0.025 * (1 - p)]}
    >
      {geometry.map((g, i) => (
        <mesh
          key={i}
          geometry={g}
          position={[
            (i - 2) *
              (1 -
                frameEase(
                  (time - (outro ? 0.04 : 0.12) * i) / (outro ? 0.72 : 1.9),
                )) *
              3.5,
            Math.sin(i * 2) *
              (1 -
                frameEase(
                  (time - (outro ? 0.04 : 0.12) * i) / (outro ? 0.72 : 1.9),
                )) *
              2.2,
            -(
              1 -
              frameEase(
                (time - (outro ? 0.04 : 0.12) * i) / (outro ? 0.72 : 1.9),
              )
            ) *
              (4 + i * 1.3),
          ]}
          rotation={[
            (1 -
              frameEase(
                (time - (outro ? 0.04 : 0.12) * i) / (outro ? 0.72 : 1.9),
              )) *
              (0.6 - i * 0.2),
            (1 -
              frameEase(
                (time - (outro ? 0.04 : 0.12) * i) / (outro ? 0.72 : 1.9),
              )) *
              (i - 2) *
              1.2,
            (1 -
              frameEase(
                (time - (outro ? 0.04 : 0.12) * i) / (outro ? 0.72 : 1.9),
              )) *
              Math.sin(i) *
              0.9,
          ]}
        >
          <Chrome roughness={0.16} />
        </mesh>
      ))}
    </group>
  );
};

const MovingScreen: React.FC<{ slug: string; separation: number }> = ({
  slug,
  separation,
}) => {
  const imageHeight = slug.startsWith("zkx") ? 928 : 824;
  const { advance } = useThree();
  const [canvas] = useState(() => {
    const c = document.createElement("canvas");
    c.width = 512;
    c.height = imageHeight;
    return c;
  });
  const ctx = useMemo(() => canvas.getContext("2d")!, [canvas]);
  const texture = useMemo(() => {
    const t = new THREE.CanvasTexture(canvas);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [canvas]);
  const mask = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = 512;
    c.height = imageHeight;
    const x = c.getContext("2d")!;
    x.fillStyle = "black";
    x.fillRect(0, 0, 512, imageHeight);
    x.fillStyle = "white";
    x.beginPath();
    x.roundRect(0, 0, 512, imageHeight, 28);
    x.fill();
    return new THREE.CanvasTexture(c);
  }, [imageHeight]);
  const onFrame = useCallback(
    (frame: CanvasImageSource) => {
      ctx.drawImage(frame, 0, 0, 512, imageHeight);
      texture.needsUpdate = true;
      advance(performance.now());
    },
    [ctx, texture, advance, imageHeight],
  );
  return (
    <>
      <Video
        src={staticFile(`vertical/captures/${slug}.mp4`)}
        headless
        muted
        onVideoFrame={onFrame}
      />
      <mesh position={[0, 0, 0.183 + separation]}>
        <planeGeometry args={[2.5, (2.5 * imageHeight) / 512]} />
        <meshBasicMaterial
          map={texture}
          alphaMap={mask}
          transparent
          toneMapped={false}
        />
      </mesh>
    </>
  );
};
const Screen: React.FC<{ slug: string; from: number; separation: number }> = ({
  slug,
  from,
  separation,
}) => (
  <Sequence from={from} layout="none">
    <MovingScreen slug={slug} separation={separation} />
  </Sequence>
);

const Device: React.FC<{
  slug: string;
  from: number;
  time: number;
  glass?: boolean;
  scale?: number;
}> = ({ slug, from, time, glass = false, scale = 1 }) => {
  const f = time * 30;
  const pose = deviceAt(slug, f);
  const separation = 1 - pose.assembly;
  const displayHeight = (2.5 * (slug.startsWith("zkx") ? 928 : 824)) / 512;
  return (
    <group
      scale={pose.scale * scale}
      rotation={pose.rotation}
      position={pose.position}
    >
      <RoundedBox
        args={[2.72, displayHeight + 0.22, glass ? 0.12 : 0.24]}
        radius={glass ? 0.09 : 0.2}
        smoothness={4}
        position={[0, 0, -separation * 0.8]}
      >
        <Chrome roughness={0.19} />
      </RoundedBox>
      <RoundedBox
        args={[2.62, displayHeight + 0.12, 0.06]}
        position={[0, 0, 0.145 + separation * 0.6]}
        radius={0.17}
        smoothness={4}
      >
        <meshStandardMaterial
          color="#030405"
          roughness={0.24}
          metalness={0.5}
        />
      </RoundedBox>
      <Screen slug={slug} from={from} separation={separation * 1.1} />
      {!glass ? (
        <>
          <RoundedBox
            args={[0.72, 0.9, 0.08]}
            radius={0.12}
            smoothness={3}
            position={[-0.73, 1.45, -0.17 - separation * 0.8]}
          >
            <Chrome roughness={0.28} />
          </RoundedBox>
          {[
            [-0.87, 1.64],
            [-0.57, 1.43],
            [-0.87, 1.23],
          ].map(([x, y], i) => (
            <group key={i} position={[x, y, -0.24 - separation * 0.8]}>
              <mesh rotation={[Math.PI / 2, 0, 0]}>
                <cylinderGeometry args={[0.108, 0.108, 0.035, 24]} />
                <Chrome roughness={0.14} />
              </mesh>
              <mesh position={[0, 0, -0.021]} rotation={[0, Math.PI, 0]}>
                <circleGeometry args={[0.084, 24]} />
                <meshStandardMaterial
                  color="#0b1019"
                  metalness={0.65}
                  roughness={0.09}
                />
              </mesh>
            </group>
          ))}
          <RoundedBox
            args={[0.49, 0.095, 0.027]}
            radius={0.045}
            smoothness={3}
            position={[0, 2.14, 0.202]}
          >
            <meshStandardMaterial
              color="#020204"
              roughness={0.22}
              metalness={0.65}
            />
          </RoundedBox>
          <mesh position={[0.16, 2.138, 0.223]}>
            <sphereGeometry args={[0.025, 12, 8]} />
            <meshStandardMaterial
              color="#1c2434"
              metalness={0.7}
              roughness={0.1}
            />
          </mesh>
          <RoundedBox
            args={[0.045, 0.55, 0.09]}
            radius={0.02}
            position={[-1.38, 1.05, 0]}
          >
            <Chrome />
          </RoundedBox>
          <RoundedBox
            args={[0.045, 0.37, 0.09]}
            radius={0.02}
            position={[1.38, 0.8, 0]}
          >
            <Chrome />
          </RoundedBox>
        </>
      ) : null}
    </group>
  );
};

const ChromeWord: React.FC<{
  children: string;
  position: [number, number, number];
  scale?: number;
}> = ({ children, position, scale = 0.2 }) => (
  <group position={position} scale={scale}>
    <Center>
      <Text3D
        font={staticFile("vertical/typeface.json")}
        size={1}
        height={0.065}
        bevelEnabled
        bevelSize={0.012}
        bevelThickness={0.008}
        bevelSegments={2}
        curveSegments={6}
      >
        <meshStandardMaterial
          color="#d5d9e2"
          metalness={0.9}
          roughness={0.24}
          emissive="#b7beca"
          emissiveIntensity={0.08}
          envMapIntensity={0.75}
        />
        {children}
      </Text3D>
    </Center>
  </group>
);

const Camera: React.FC<{ time: number }> = ({ time }) => {
  const { camera, scene } = useThree();
  const f = time * 30;
  useLayoutEffect(() => {
    const pose = cameraAt(f);
    camera.position.set(...pose.position);
    camera.lookAt(...pose.target);
    if (camera instanceof THREE.PerspectiveCamera)
      camera.fov = 39 + transitionAt(f).strength * 4;
    camera.updateProjectionMatrix();
    scene.environmentRotation.set(
      0.025 * Math.sin(f * 0.01),
      Math.sin(f * 0.006) * 0.45,
      0,
    );
  }, [camera, scene, f]);
  return null;
};

const CapturedPanel: React.FC<{
  asset: string;
  position: Vec3;
  rotation?: Vec3;
  width?: number;
  scale?: number;
}> = ({ asset, position, rotation = [0, 0, 0], width = 1.6, scale = 1 }) => {
  const source = useLoader(
    THREE.TextureLoader,
    staticFile(`vertical/captures/${asset}.png`),
  );
  const texture = useMemo(() => {
    const t = source.clone();
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [source]);
  const image = source.image as HTMLImageElement;
  const h = (width * image.height) / image.width;
  return (
    <group
      position={position}
      rotation={rotation}
      scale={Math.max(0.001, scale)}
    >
      <RoundedBox
        args={[width + 0.09, h + 0.09, 0.075]}
        radius={0.045}
        smoothness={3}
      >
        <Chrome roughness={0.2} />
      </RoundedBox>
      <mesh position={[0, 0, 0.043]}>
        <planeGeometry args={[width, h]} />
        <meshBasicMaterial map={texture} toneMapped={false} />
      </mesh>
    </group>
  );
};

/** A layered chrome aperture replaces the repeated flat-circle background. */
const Aperture: React.FC<{
  frame: number;
  position?: Vec3;
  scale?: number;
}> = ({ frame, position = [0, 0, 0], scale = 1 }) => {
  const blast = transitionAt(frame).strength;
  return (
    <group position={position} scale={scale}>
      {[0, 1, 2].map((i) => (
        <group
          key={i}
          position={[
            Math.sin(i * 1.6) * 0.65,
            Math.cos(i * 2) * 0.25,
            -4 - i * 5,
          ]}
          rotation={[
            0.03 * i,
            Math.sin(frame * 0.003 + i) * 0.12,
            (i - 1) * 0.13 + Math.sin(frame * 0.002) * 0.04,
          ]}
        >
          {[-1, 1].map((sign) => (
            <React.Fragment key={sign}>
              <RoundedBox
                args={[0.065, 6.5, 0.11]}
                radius={0.025}
                smoothness={2}
                position={[sign * 2.65, 0, 0]}
              >
                <meshStandardMaterial
                  color="#3c424e"
                  metalness={0.9}
                  roughness={0.32}
                  envMapIntensity={0.38}
                />
              </RoundedBox>
              <RoundedBox
                args={[5.36, 0.065, 0.11]}
                radius={0.025}
                smoothness={2}
                position={[0, sign * 3.25, 0]}
              >
                <meshStandardMaterial
                  color="#3c424e"
                  metalness={0.9}
                  roughness={0.32}
                  envMapIntensity={0.38}
                />
              </RoundedBox>
            </React.Fragment>
          ))}
        </group>
      ))}
      {Array.from({ length: 10 }, (_, i) => (
        <mesh
          key={i}
          position={[
            (i % 2 ? -1 : 1) * (3.1 + (i % 3) * 0.8),
            Math.sin(i * 3.1 + frame * 0.002) * 3.5,
            -3 - (i % 5) * 3.8,
          ]}
          rotation={[i * 0.4 + frame * 0.002, i * 0.7 + frame * 0.003, i * 0.3]}
          scale={0.08 + (i % 3) * 0.055}
        >
          <octahedronGeometry args={[1, 0]} />
          <meshStandardMaterial
            color="#3c424e"
            metalness={0.9}
            roughness={0.28}
            envMapIntensity={0.85}
          />
        </mesh>
      ))}
      <pointLight
        position={[Math.sin(frame * 0.016) * 4, 2.7, 3]}
        intensity={12 + blast * 16}
        color="#f1f4fa"
      />
    </group>
  );
};

const DetachingInterfaces: React.FC<{ frame: number }> = ({ frame: f }) => {
  if (f < 285 || f > 442) return null;
  const pop = frameEase((f - 285) / 28);
  const gather = frameEase((f - 397) / 32);
  const leave = 1 - frameEase((f - 432) / 10);
  return (
    <>
      <CapturedPanel
        asset="zkx-portfolio"
        width={1.55}
        position={[
          frameMix(1.7, 0, gather),
          frameMix(0.5, 0, gather),
          frameMix(0.7, 4.1, gather),
        ]}
        rotation={[0.04, frameMix(-0.3, 0, gather), frameMix(0.07, 0, gather)]}
        scale={pop * leave}
      />
      <CapturedPanel
        asset="zkx-services"
        width={1.45}
        position={[
          -1.8 + gather * 1.5,
          -0.45 + gather * 0.4,
          -0.75 + gather * 2,
        ]}
        rotation={[-0.03, 0.26, -0.05]}
        scale={frameEase((f - 303) / 26) * (1 - gather * 0.8) * leave}
      />
    </>
  );
};
const MetalShutter: React.FC<{ frame: number }> = ({ frame: f }) => {
  if (f < 544 || f > 587) return null;
  const close = frameEase((f - 544) / 15),
    open = frameEase((f - 560) / 27);
  const spread = 1 - close + open;
  return (
    <group position={[0.15, 0, 0.75]} rotation={[0, 0, (1 - spread) * 0.08]}>
      {[-1.5, -0.5, 0.5, 1.5].map((n, i) => (
        <RoundedBox
          key={n}
          args={[0.73, 5.25, 0.11]}
          radius={0.025}
          smoothness={2}
          position={[n * (0.72 + spread * 6), Math.sin(i) * spread * 0.3, 0]}
          rotation={[0, n * spread * 0.17, 0]}
        >
          <Chrome roughness={0.2} />
        </RoundedBox>
      ))}
    </group>
  );
};
const PortfolioConstellation: React.FC<{ frame: number }> = ({ frame: f }) => {
  if (f < 780 || f > 920) return null;
  const retreat = frameEase((f - 780) / 120),
    launch = frameEase((f - 780) / 30);
  const disappear = 1 - frameEase((f - 890) / 30);
  return (
    <>
      <CapturedPanel
        asset="etp"
        width={1.5}
        position={[-2.3 * (1 + retreat * 0.7), -0.3, -2.2 - retreat * 7]}
        rotation={[0.04, 0.35 + retreat * 0.4, -0.06]}
        scale={disappear}
      />
      <CapturedPanel
        asset="bk"
        width={1.5}
        position={[1 + retreat, 1.7, -5 - retreat * 7]}
        rotation={[0.04, retreat * 0.4, 0]}
        scale={disappear}
      />
      <CapturedPanel
        asset="nero-end"
        width={1.5}
        position={[
          frameMix(0.2, 2.3, launch) * (1 + retreat * 0.7),
          frameMix(0.15, -0.3, launch),
          -3.5 - retreat * 7,
        ]}
        rotation={[
          frameMix(0.14, 0.04, launch),
          frameMix(0.7, -0.35, launch) + retreat * 0.4,
          frameMix(0.15, 0.06, launch),
        ]}
        scale={disappear * frameMix(1.13, 1, launch)}
      />
    </>
  );
};

export const VerticalWorld: React.FC<{ time: number }> = ({ time: t }) => {
  const f = t * 30,
    main = f >= 150 && f < 450,
    portfolio = f >= 450 && f < 780,
    impact = f >= 780 && f < 930;
  const slug = f < 560 ? "etp" : f < 670 ? "bk" : "nero";
  const impactWords = [
    "VISIBILITY",
    "CREDIBILITY",
    "BRAND IMAGE",
    "PERFORMANCE",
    "USER EXPERIENCE",
    "GROWTH",
  ];
  const mainWord =
    f < 252 ? "WEB DESIGN" : f < 351 ? "DIGITAL PRESENCE" : "ONLINE VISIBILITY";
  const index = Math.min(5, Math.floor((f - 780) / 25));
  const word = main ? mainWord : impact ? impactWords[index] : "";
  const wordStart = main
    ? f < 252
      ? 165
      : f < 351
        ? 252
        : 351
    : 780 + index * 25;
  const wordPop = frameEase((f - wordStart) / 12);
  const wordExit = main
    ? 1 - frameEase((f - 408) / 18)
    : 1 - frameEase((f - 908) / 17);
  return (
    <>
      <color attach="background" args={["#020204"]} />
      <fog attach="fog" args={["#020204", 23, 58]} />
      <Lighting />
      <Camera time={t} />
      <Dust />
      <Aperture frame={f} />
      {f < 150 ? (
        <>
          <Brand time={t} />
          <Ring
            radius={3.3}
            tube={0.024}
            position={[0, 0.4, -2]}
            rotation={[0.35, 0.45, t * 0.1]}
          />
        </>
      ) : null}
      {main ? (
        <>
          <Device slug="zkx-main" from={150} time={t} />
          <DetachingInterfaces frame={f} />
        </>
      ) : null}
      {portfolio ? (
        <Device
          slug={slug}
          from={slug === "etp" ? 450 : slug === "bk" ? 560 : 670}
          time={t}
          glass
        />
      ) : null}
      <MetalShutter frame={f} />
      {impact ? (
        <>
          <Device slug="zkx-impact" from={780} time={t} />
          <PortfolioConstellation frame={f} />
        </>
      ) : null}
      {(main || impact) && wordExit > 0.001 ? (
        <group
          position={[0, impact ? -2.9 : 2.85, -(1 - wordPop) * 4]}
          rotation={[0, (1 - wordPop) * -0.6, 0]}
          scale={Math.max(0.001, wordPop * wordExit)}
        >
          <ChromeWord
            position={[0, 0, 0.9]}
            scale={word.length > 15 ? 0.18 : 0.22}
          >
            {word}
          </ChromeWord>
        </group>
      ) : null}
      {f >= 930 ? (
        <>
          <Brand time={t - 31} outro />
          <Ring
            radius={3.4}
            tube={0.026}
            position={[0, 0.8, -2]}
            rotation={[0.3, 0.15, (t - 31) * 0.05]}
          />
        </>
      ) : null}
      <EffectComposer multisampling={0}>
        <Bloom
          luminanceThreshold={1.7}
          intensity={0.14}
          mipmapBlur={false}
          resolutionScale={0.25}
        />
        <DepthOfField
          focusDistance={focusAt(f)}
          focalLength={0.28}
          bokehScale={0.1}
          resolutionScale={0.25}
        />
        <SpeedBlur frame={f} />
        <FXAA />
      </EffectComposer>
    </>
  );
};
