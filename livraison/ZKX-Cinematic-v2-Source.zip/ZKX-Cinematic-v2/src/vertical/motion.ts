/** Cinematic keyframes, in Remotion frames. No wall-clock animation state. */
export type Vec3 = [number, number, number];
export type Pose = {
  position: Vec3;
  rotation: Vec3;
  scale: number;
  assembly: number;
};
type DeviceKey = { frame: number; p: Vec3; r: Vec3; s?: number; a?: number };
type CameraKey = { frame: number; p: Vec3; target: Vec3 };
export const ease = (v: number) => {
  const p = Math.max(0, Math.min(1, v));
  return p * p * (3 - 2 * p);
};
export const mix = (a: number, b: number, p: number) => a + (b - a) * p;
export const mix3 = (a: Vec3, b: Vec3, p: number): Vec3 => [
  mix(a[0], b[0], p),
  mix(a[1], b[1], p),
  mix(a[2], b[2], p),
];
function segment<T extends { frame: number }>(
  keys: T[],
  f: number,
): [T, T, number] {
  if (f <= keys[0].frame) return [keys[0], keys[0], 0];
  for (let i = 0; i < keys.length - 1; i++)
    if (f <= keys[i + 1].frame)
      return [
        keys[i],
        keys[i + 1],
        ease((f - keys[i].frame) / (keys[i + 1].frame - keys[i].frame)),
      ];
  return [keys[keys.length - 1], keys[keys.length - 1], 0];
}
const cameraKeys: CameraKey[] = [
  { frame: 0, p: [6, 1.8, 12], target: [0, 0.4, 0] },
  { frame: 18, p: [4, 1.4, 11], target: [0, 0.4, 0] },
  { frame: 65, p: [-2, 1, 10.4], target: [0, 0.4, 0] },
  { frame: 98, p: [-0.4, 0.4, 11.6], target: [0, 0.4, 0] },
  { frame: 120, p: [0.1, 0.3, 10.2], target: [0.15, 0.3, -0.1] },
  { frame: 135, p: [0.2, 0.25, 6.5], target: [0.2, 0.25, -0.4] },
  { frame: 149, p: [0.3, 0.22, 0.23], target: [0.3, 0.22, -1] },
  { frame: 150, p: [0.2, 0.15, 0.5], target: [0, 0, -8] },
  { frame: 174, p: [-1.4, 0.8, 12.8], target: [0.5, 0, -0.5] },
  { frame: 205, p: [1.4, 0.5, 11.3], target: [0.25, 0, 0] },
  { frame: 240, p: [-0.8, 0.4, 10.9], target: [-0.4, 0, 0] },
  { frame: 285, p: [-1.5, 0.55, 11.7], target: [-0.5, 0.05, 0] },
  { frame: 315, p: [1.6, 0.6, 12.6], target: [0, 0, 0.2] },
  { frame: 365, p: [-1.2, 0.7, 11.7], target: [0, 0.2, 0] },
  { frame: 405, p: [0.65, 0.3, 10.5], target: [0, 0, 0.1] },
  { frame: 426, p: [0.15, 0.15, 6.5], target: [0, 0, -0.5] },
  { frame: 449, p: [0, 0.15, 0.23], target: [0, 0, -2] },
  { frame: 450, p: [0, 0.1, 0.4], target: [0, 0, -8] },
  { frame: 474, p: [1.8, 0.8, 12.8], target: [0.15, 0.1, 0] },
  { frame: 512, p: [-1.1, 0.55, 11.3], target: [-0.15, 0, 0.1] },
  { frame: 543, p: [0.4, 0.25, 11.9], target: [0.1, 0, 0.1] },
  { frame: 559, p: [0, 0.2, 11.5], target: [0.1, 0, 0] },
  { frame: 560, p: [0, 0.2, 11.5], target: [0.1, 0, 0] },
  { frame: 582, p: [-1.8, 0.8, 12.5], target: [-0.25, 0, -0.1] },
  { frame: 620, p: [1.4, 0.4, 11.5], target: [0.1, 0, 0] },
  { frame: 641, p: [0.4, 0.2, 10.6], target: [0, 0, -0.1] },
  { frame: 654, p: [0.12, 0.05, 6.8], target: [0, 0, -0.5] },
  { frame: 669, p: [0, 0.02, 0.23], target: [0, 0, -2] },
  { frame: 670, p: [0, 0.02, 0.4], target: [0, 0, -7] },
  { frame: 695, p: [-1.4, 0.6, 12.6], target: [0.25, 0.05, 0] },
  { frame: 730, p: [1.5, 0.4, 11.8], target: [0, 0, 0] },
  { frame: 756, p: [0.2, 0.1, 11.3], target: [0.1, 0, 0] },
  { frame: 779, p: [0, 0.25, 9.4], target: [0, 0, -1] },
  { frame: 780, p: [0, 0.25, 9.4], target: [0, 0, -1] },
  { frame: 802, p: [0.8, 0.7, 14.4], target: [0, 0, -0.5] },
  { frame: 835, p: [-1.2, 0.55, 13.7], target: [0, -0.1, 0] },
  { frame: 879, p: [0.9, 0.4, 12.4], target: [0, -0.1, 0] },
  { frame: 910, p: [0, 0.2, 10.2], target: [0, 0, -0.1] },
  { frame: 929, p: [0, 0.2, 0.3], target: [0, 0, -2] },
  { frame: 930, p: [0, 0.2, 0.4], target: [0, 0.6, -5] },
  { frame: 946, p: [3, 1.2, 10.6], target: [0, 0.7, 0] },
  { frame: 968, p: [-0.6, 0.7, 11.5], target: [0, 0.7, 0] },
  { frame: 980, p: [0.4, 0.25, 12.4], target: [0, 0.6, 0] },
  { frame: 1018, p: [0, 0.25, 13], target: [0, 0.6, 0] },
  { frame: 1049, p: [0, 0.25, 13.4], target: [0, 0.6, 0] },
];
const deviceKeys: Record<string, DeviceKey[]> = {
  "zkx-main": [
    { frame: 150, p: [0, 0, -8], r: [0.2, -1.3, 0.15], s: 0.8, a: 0 },
    { frame: 174, p: [0.65, -0.05, -0.4], r: [0.06, -0.35, -0.08], a: 1 },
    { frame: 220, p: [0.25, 0.05, 0.1], r: [0.02, -0.17, -0.03] },
    { frame: 270, p: [-0.65, 0.08, 0], r: [0.04, 0.26, 0.045] },
    { frame: 320, p: [-0.7, -0.05, -0.4], r: [-0.03, 0.35, -0.06], s: 0.94 },
    { frame: 370, p: [0.2, 0, 0], r: [0.03, -0.18, 0.04] },
    { frame: 405, p: [0, 0, 0], r: [0, 0, 0] },
    { frame: 449, p: [0, 0, 0], r: [0, 0, 0], s: 1.02 },
  ],
  etp: [
    { frame: 450, p: [0, 0, -8], r: [0.25, -1.1, -0.14], s: 0.72, a: 0 },
    { frame: 476, p: [0.4, 0.1, -0.1], r: [0, -0.22, -0.05], a: 1 },
    { frame: 515, p: [-0.25, 0, 0.15], r: [0.03, 0.18, 0.035] },
    { frame: 541, p: [0.2, 0, 0.15], r: [0.02, -0.05, 0] },
    { frame: 559, p: [0.15, 0, 0.15], r: [0, Math.PI / 2, 0] },
  ],
  bk: [
    { frame: 560, p: [0.15, 0, 0.15], r: [0, -Math.PI / 2, 0] },
    { frame: 581, p: [-0.4, -0.05, -0.15], r: [0.04, 0.3, 0.04] },
    { frame: 620, p: [0.25, 0, 0.2], r: [-0.04, -0.2, -0.035] },
    { frame: 641, p: [0, 0, 0], r: [0, 0, 0] },
    { frame: 669, p: [0, 0, 0], r: [0, 0, 0] },
  ],
  nero: [
    { frame: 670, p: [0, 0, -6.5], r: [0.1, 0.25, -0.08], a: 0.3 },
    { frame: 695, p: [0.35, 0.1, -0.1], r: [-0.03, -0.3, 0.06], a: 1 },
    { frame: 730, p: [-0.25, 0, 0.1], r: [0.04, 0.22, -0.04] },
    { frame: 756, p: [0.1, 0, 0], r: [0, -0.15, 0] },
    { frame: 779, p: [0.2, 0.15, -3.5], r: [0.14, 0.7, 0.15], s: 0.68 },
  ],
  "zkx-impact": [
    { frame: 780, p: [0, -0.1, -6], r: [0.15, -0.5, -0.12], s: 0.8, a: 0.4 },
    { frame: 803, p: [0, -0.2, 0], r: [0.03, 0.12, 0], s: 0.88, a: 1 },
    { frame: 840, p: [-0.25, -0.2, 0], r: [0.03, -0.17, -0.04], s: 0.88 },
    { frame: 880, p: [0.2, -0.2, 0], r: [-0.02, 0.15, 0.03], s: 0.9 },
    { frame: 908, p: [0, -0.1, 0], r: [0, 0, 0], s: 0.95 },
    { frame: 929, p: [0, 0, 0], r: [0, 0.02, 0] },
  ],
};
export function cameraAt(frame: number) {
  const [a, b, p] = segment(cameraKeys, frame);
  return { position: mix3(a.p, b.p, p), target: mix3(a.target, b.target, p) };
}
export function deviceAt(slug: string, frame: number): Pose {
  const keys = deviceKeys[slug];
  if (!keys) throw new Error(`Unknown device ${slug}`);
  const [a, b, p] = segment(keys, frame);
  return {
    position: mix3(a.p, b.p, p),
    rotation: mix3(a.r, b.r, p),
    scale: mix(a.s ?? 1, b.s ?? 1, p),
    assembly: mix(a.a ?? 1, b.a ?? 1, p),
  };
}
export const cuts = [150, 450, 560, 670, 780, 930];
export function transitionAt(frame: number) {
  let strength = 0,
    cut = 0;
  for (const c of cuts) {
    const p =
      frame < c ? ease((frame - c + 12) / 12) : 1 - ease((frame - c) / 7);
    if (p > strength) {
      strength = p;
      cut = c;
    }
  }
  return {
    strength: cut === 780 ? strength * 0.35 : strength,
    zoom: cut !== 560,
    flash:
      cut && cut !== 780
        ? Math.max(0, 1 - Math.abs(frame - cut) / 3) * 0.22
        : 0,
  };
}

/** Frame-controlled focus pull follows the subject as the camera dollies. */
export function focusAt(frame: number): number {
  const c = cameraAt(frame);
  let target: Vec3 =
    frame < 150
      ? [0, 0.4, 0]
      : frame >= 930
        ? [0, 1.1, 0]
        : deviceAt(
            frame < 450
              ? "zkx-main"
              : frame < 560
                ? "etp"
                : frame < 670
                  ? "bk"
                  : frame < 780
                    ? "nero"
                    : "zkx-impact",
            frame,
          ).position;
  if (frame >= 780 && frame < 803)
    target = mix3([0.2, 0.15, -3.5], target, ease((frame - 780) / 23));
  const forward = c.target.map((v, i) => v - c.position[i]);
  const length = Math.hypot(...forward);
  const depth = target.reduce(
    (sum, v, i) => sum + ((v - c.position[i]) * forward[i]) / length,
    0,
  );
  return Math.max(0.002, Math.min(0.98, (depth - 0.1) / 59.9));
}
