import React from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  Easing,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { World } from "./World";

const smooth = Easing.bezier(0.22, 1, 0.36, 1);
const range = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: smooth,
  });
const mono: React.CSSProperties = {
  fontFamily: '"Courier New", monospace',
  fontSize: 16,
  letterSpacing: 3,
  fontWeight: 400,
};
const label: React.CSSProperties = {
  fontSize: 17,
  letterSpacing: 5,
  fontWeight: 400,
  textTransform: "uppercase",
  color: "#b9bfc9",
};

const Reveal: React.FC<{
  children: React.ReactNode;
  frame: number;
  start: number;
  delay?: number;
  style?: React.CSSProperties;
}> = ({ children, frame, start, delay = 0, style }) => {
  const p = range(frame, start + delay, start + delay + 26);
  return (
    <div style={{ overflow: "hidden", ...style }}>
      <div
        style={{
          transform: p > 0.999 ? "none" : `translateY(${(1 - p) * 112}%)`,
          opacity: p > 0.999 ? 1 : p,
        }}
      >
        {children}
      </div>
    </div>
  );
};
const LeftCopy: React.FC<{
  f: number;
  start: number;
  tag: string;
  lines: string[];
  body: string;
  bottom: string;
}> = ({ f, start, tag, lines, body, bottom }) => (
  <div style={{ position: "absolute", left: 116, top: 285, width: 670 }}>
    <Reveal frame={f} start={start} style={{ ...label, marginBottom: 34 }}>
      {tag}
    </Reveal>
    {lines.map((line, i) => (
      <Reveal
        key={line}
        frame={f}
        start={start}
        delay={6 + i * 4}
        style={{
          fontSize: 105,
          lineHeight: 1.08,
          letterSpacing: -4.5,
          fontWeight: 400,
        }}
      >
        {line}
      </Reveal>
    ))}
    <Reveal
      frame={f}
      start={start}
      delay={18}
      style={{
        fontSize: 25,
        lineHeight: 1.5,
        color: "#a8adb7",
        marginTop: 33,
        maxWidth: 490,
      }}
    >
      {body}
    </Reveal>
    <Reveal
      frame={f}
      start={start}
      delay={25}
      style={{ ...mono, fontSize: 13, color: "#777f8f", marginTop: 44 }}
    >
      {bottom}
    </Reveal>
  </div>
);

export const ZkxFilm: React.FC = () => {
  const f = useCurrentFrame();
  const t = f / 30;
  const chapter = t < 5 ? 0 : t < 12 ? 1 : t < 22 ? 2 : t < 30 ? 3 : 4;
  const titles = [
    "NOUVELLE DIMENSION",
    "PRÉSENCE DIGITALE",
    "CRÉATION WEB",
    "IMPACT ENTREPRISE",
    "ZKX DIGITAL LAB",
  ];
  const sections = [0, 150, 360, 510, 660, 780, 900];
  const dip = Math.max(
    ...sections.slice(1).map((c) =>
      interpolate(f, [c - 7, c, c + 8], [0, 0.96, 0], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      }),
    ),
  );
  const opening = range(f, 0, 30);
  const ending = interpolate(f, [1032, 1049], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return (
    <AbsoluteFill
      style={{
        backgroundColor: "#020305",
        color: "#f3f4f7",
        fontFamily: "Arial, Helvetica, sans-serif",
      }}
    >
      <Audio src={staticFile("zkx-score.wav")} volume={0.82} />
      <ThreeCanvas
        width={1280}
        height={720}
        style={{ transform: "scale(1.5)", transformOrigin: "top left" }}
        camera={{ fov: 43, near: 0.1, far: 100 }}
        gl={{
          antialias: true,
          alpha: false,
          powerPreference: "high-performance",
        }}
        dpr={1}
      >
        <World time={t} />
      </ThreeCanvas>
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse at 55% 42%, transparent 26%, rgba(0,0,0,.42) 100%)",
          pointerEvents: "none",
        }}
      />
      {/* Restrained editorial frame and chapter system. */}
      <div
        style={{
          position: "absolute",
          left: 82,
          right: 82,
          top: 60,
          zIndex: 5,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          opacity: opening * 0.85,
        }}
      >
        <div style={{ fontSize: 19, fontWeight: 600, letterSpacing: 4 }}>
          ZKX{" "}
          <span
            style={{
              fontWeight: 400,
              fontSize: 13,
              letterSpacing: 3,
              marginLeft: 13,
              color: "#a0a6b1",
            }}
          >
            DIGITAL LAB
          </span>
        </div>
        <div style={{ ...mono, fontSize: 12, color: "#8f96a1" }}>
          STUDIO DIGITAL INDÉPENDANT{" "}
          <span style={{ margin: "0 20px", color: "#414651" }}>/</span> DESIGN ×
          TECHNOLOGIE
        </div>
      </div>
      {t < 5 ? (
        <>
          <div
            style={{
              position: "absolute",
              top: 255,
              width: "100%",
              textAlign: "center",
            }}
          >
            <Reveal frame={f} start={8} style={label}>
              UNE NOUVELLE DIMENSION DIGITALE
            </Reveal>
          </div>
          <div
            style={{
              position: "absolute",
              top: 687,
              width: "100%",
              textAlign: "center",
            }}
          >
            <Reveal
              frame={f}
              start={25}
              style={{ fontSize: 26, letterSpacing: 13, fontWeight: 400 }}
            >
              D I G I T A L L A B
            </Reveal>
            <Reveal
              frame={f}
              start={48}
              style={{
                fontSize: 20,
                letterSpacing: 1.1,
                color: "#a7acb6",
                marginTop: 37,
              }}
            >
              Une présence forte. De nouvelles perspectives.
            </Reveal>
          </div>
        </>
      ) : null}
      {t >= 5 && t < 12 ? (
        <>
          <AbsoluteFill
            style={{
              background:
                "linear-gradient(90deg,rgba(2,3,5,.9),rgba(2,3,5,.72) 31%,transparent 59%)",
            }}
          />
          <LeftCopy
            f={f}
            start={153}
            tag="01 / SOYEZ VISIBLE"
            lines={["La première", "impression", "est digitale."]}
            body="Votre entreprise mérite une présence en ligne forte."
            bottom="VISIBILITÉ EN LIGNE / IMAGE DE MARQUE"
          />
        </>
      ) : null}
      {t >= 12 && t < 17.1 ? (
        <>
          <div style={{ position: "absolute", left: 116, top: 139 }}>
            <Reveal frame={f} start={363} style={label}>
              02 / AFFIRMEZ VOTRE DIFFÉRENCE
            </Reveal>
            <Reveal
              frame={f}
              start={370}
              style={{
                fontSize: 55,
                letterSpacing: -1.9,
                lineHeight: 1.2,
                marginTop: 18,
              }}
            >
              Entreprises modernes. Sites modernes.
            </Reveal>
          </div>
          <div
            style={{
              position: "absolute",
              left: 116,
              right: 116,
              bottom: 156,
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <span style={label}>CRÉATION WEB</span>
            <span style={label}>EXPÉRIENCE UTILISATEUR</span>
            <span style={label}>EXPÉRIENCE PREMIUM</span>
          </div>
        </>
      ) : null}
      {t >= 17.1 && t < 22 ? (
        <>
          <div style={{ position: "absolute", left: 116, top: 139 }}>
            <Reveal frame={f} start={516} style={label}>
              UNE IDENTITÉ. SUR TOUS LES ÉCRANS.
            </Reveal>
            <Reveal
              frame={f}
              start={522}
              style={{
                fontSize: 61,
                letterSpacing: -2,
                lineHeight: 1.2,
                marginTop: 20,
              }}
            >
              Votre vitrine digitale.
            </Reveal>
          </div>
          <div
            style={{
              position: "absolute",
              left: 116,
              bottom: 166,
              ...mono,
              fontSize: 15,
              color: "#bbc1ca",
            }}
          >
            UN DESIGN SOIGNÉ. UN IMPACT CONCRET.
          </div>
        </>
      ) : null}
      {t >= 22 && t < 26 ? (
        <>
          <AbsoluteFill
            style={{
              background:
                "linear-gradient(90deg,rgba(2,3,5,.82),transparent 65%)",
            }}
          />
          <LeftCopy
            f={f}
            start={663}
            tag="03 / INSPIREZ CONFIANCE"
            lines={["Un site web", "inspire", "confiance."]}
            body="Une image crédible. Une impression durable."
            bottom="CRÉDIBILITÉ / IMAGE DE MARQUE"
          />
        </>
      ) : null}
      {t >= 26 && t < 30 ? (
        <>
          <AbsoluteFill
            style={{
              background:
                "linear-gradient(90deg,rgba(2,3,5,.82),transparent 65%)",
            }}
          />
          <LeftCopy
            f={f}
            start={783}
            tag="04 / VISEZ PLUS LOIN"
            lines={["Pensé pour", "votre", "croissance."]}
            body="Faites de votre présence un levier de croissance."
            bottom="PERFORMANCE / CONVERSION / CROISSANCE"
          />
        </>
      ) : null}
      {t >= 30 ? (
        <>
          <div
            style={{
              position: "absolute",
              top: 599,
              width: "100%",
              textAlign: "center",
            }}
          >
            <Reveal
              frame={f}
              start={906}
              style={{ fontSize: 25, letterSpacing: 12 }}
            >
              DIGITAL LAB
            </Reveal>
            <Reveal
              frame={f}
              start={920}
              style={{ fontSize: 44, letterSpacing: -1.2, marginTop: 47 }}
            >
              Construisez votre présence digitale.
            </Reveal>
            <Reveal
              frame={f}
              start={933}
              style={{
                fontSize: 20,
                color: "#9ba2af",
                letterSpacing: 1,
                marginTop: 18,
              }}
            >
              Des sites web pour les entreprises modernes
            </Reveal>
            <Reveal
              frame={f}
              start={948}
              style={{
                ...mono,
                fontSize: 14,
                letterSpacing: 1.8,
                color: "#c8ccd4",
                marginTop: 46,
              }}
            >
              ZKX.DIGITAL@GMAIL.COM{" "}
              <span style={{ margin: "0 22px", color: "#535965" }}>/</span>{" "}
              @ZKM.31
            </Reveal>
          </div>
        </>
      ) : null}
      <div
        style={{
          position: "absolute",
          left: 82,
          right: 82,
          bottom: 52,
          zIndex: 5,
          opacity: opening * 0.82,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 19,
            ...mono,
            fontSize: 12,
            color: "#8e95a1",
          }}
        >
          <span>
            0{chapter + 1}{" "}
            <span style={{ color: "#444b57", margin: "0 13px" }}> / </span>{" "}
            {titles[chapter]}
          </span>
          <span>CONÇU POUR MARQUER LES ESPRITS</span>
          <span>
            {("0" + Math.floor(t)).slice(-2)}{" "}
            <span style={{ color: "#444b57" }}> / 35</span>
          </span>
        </div>
        <div style={{ height: 1, background: "#2c3037" }}>
          <div
            style={{
              height: 1,
              width: `${(f / 1049) * 100}%`,
              background: "#cbd0d9",
            }}
          />
        </div>
      </div>
      <AbsoluteFill style={{ opacity: 0.035, pointerEvents: "none" }}>
        <Img
          src={staticFile("zkx/grain.png")}
          style={{ width: "100%", height: "100%", opacity: 0.5 }}
        />
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          background: "#020305",
          opacity: Math.max(dip, 1 - opening, ending),
          pointerEvents: "none",
        }}
      />
    </AbsoluteFill>
  );
};
