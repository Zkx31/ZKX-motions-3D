import React, { useLayoutEffect, useMemo } from "react";
import { useLoader, useThree } from "@react-three/fiber";
import { staticFile } from "remotion";
import * as THREE from "three";
import { logoPolygons } from "./brand";
import { roundedRect } from "../helpers/rounded-rectangle";

const ease = (v: number) => {
  const x = Math.max(0, Math.min(1, v));
  return x * x * (3 - 2 * x);
};
const mix = THREE.MathUtils.lerp;

export const Lighting: React.FC = () => {
  const { gl, scene } = useThree();
  useLayoutEffect(() => {
    const room = new THREE.Scene();
    room.background = new THREE.Color("#090a0d");
    const add = (
      x: number,
      y: number,
      z: number,
      w: number,
      h: number,
      intensity: number,
      ry = 0,
      rx = 0,
    ) => {
      const m = new THREE.Mesh(
        new THREE.PlaneGeometry(w, h),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color().setScalar(intensity),
          side: THREE.DoubleSide,
        }),
      );
      m.position.set(x, y, z);
      m.rotation.set(rx, ry, 0);
      room.add(m);
    };
    add(0, 3.5, 8, 15, 5, 4);
    add(-3, -1.5, 9, 5, 2, 2);
    add(-6, 3, 3, 3, 12, 6, Math.PI / 3);
    add(6, 1, 1, 2, 14, 4, -Math.PI / 3);
    add(0, 7, 0, 14, 4, 4, 0, Math.PI / 2);
    add(0, -4, 2, 12, 2, 1.1, 0, -Math.PI / 2);
    add(-2, 1, -8, 1, 10, 5);
    add(4, 0, -7, 4, 10, 2);
    const generator = new THREE.PMREMGenerator(gl);
    const target = generator.fromScene(room, 0.025, 0.1, 100);
    scene.environment = target.texture;
    return () => {
      scene.environment = null;
      target.dispose();
      generator.dispose();
      room.traverse((o) => {
        if (o instanceof THREE.Mesh) {
          o.geometry.dispose();
          o.material.dispose();
        }
      });
    };
  }, [gl, scene]);
  return (
    <>
      <ambientLight intensity={0.24} />
      <directionalLight position={[-4, 7, 6]} intensity={3.2} />
      <pointLight position={[7, 0, 4]} intensity={50} color="#e7edff" />
      <pointLight position={[-5, -2, 2]} intensity={20} />
    </>
  );
};

export const Chrome: React.FC<{ roughness?: number; color?: string }> = ({
  roughness = 0.2,
  color = "#b8bcc4",
}) => (
  <meshStandardMaterial
    color={color}
    metalness={1}
    roughness={roughness}
    envMapIntensity={1.6}
  />
);

const Logo: React.FC<{ time: number; outro?: boolean }> = ({
  time,
  outro = false,
}) => {
  const geometries = useMemo(
    () =>
      logoPolygons.map((poly) => {
        const shape = new THREE.Shape();
        poly.forEach(([x, y], i) => {
          if (i === 0) shape.moveTo((x - 192) / 54, (49 - y) / 54);
          else shape.lineTo((x - 192) / 54, (49 - y) / 54);
        });
        shape.closePath();
        return new THREE.ExtrudeGeometry(shape, {
          depth: 0.22,
          bevelEnabled: true,
          bevelThickness: 0.055,
          bevelSize: 0.035,
          bevelSegments: 3,
          steps: 1,
        });
      }),
    [],
  );
  const p = ease(time / 3.5);
  return (
    <group
      position={[0, outro ? 0.7 : 0.35, 0]}
      rotation={[
        outro ? -0.05 : mix(0.12, 0, p),
        outro ? -0.03 : mix(-0.52, 0.08, p),
        outro ? 0 : mix(-0.08, 0, p),
      ]}
      scale={outro ? 0.91 : 1}
    >
      {geometries.map((g, i) => (
        <mesh key={i} geometry={g} position={[0, 0, 0]}>
          <Chrome roughness={0.17} />
        </mesh>
      ))}
    </group>
  );
};

export const Ring: React.FC<{
  position?: [number, number, number];
  rotation?: [number, number, number];
  radius?: number;
  tube?: number;
  dark?: boolean;
}> = ({
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  radius = 3,
  tube = 0.035,
  dark = false,
}) => (
  <mesh position={position} rotation={rotation}>
    <torusGeometry args={[radius, tube, 10, 100]} />
    <Chrome
      roughness={dark ? 0.32 : 0.18}
      color={dark ? "#333840" : "#ced1d7"}
    />
  </mesh>
);

const Panel: React.FC<{
  site: string;
  position?: [number, number, number];
  rotation?: [number, number, number];
  width?: number;
  mobile?: boolean;
}> = ({
  site,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  width = 6,
  mobile = false,
}) => {
  const texture = useLoader(THREE.TextureLoader, staticFile(`zkx/${site}.svg`));
  useMemo(() => {
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 4;
  }, [texture]);
  const height = width * (mobile ? 2 : 0.625);
  const geometry = useMemo(
    () =>
      new THREE.ExtrudeGeometry(
        roundedRect({
          width: width + 0.13,
          height: height + 0.13,
          radius: 0.1,
        }),
        {
          depth: 0.08,
          bevelEnabled: true,
          bevelThickness: 0.025,
          bevelSize: 0.018,
          bevelSegments: 2,
          steps: 1,
        },
      ),
    [width, height],
  );
  return (
    <group position={position} rotation={rotation}>
      <mesh
        geometry={geometry}
        position={[-(width + 0.13) / 2, -(height + 0.13) / 2, -0.07]}
      >
        <Chrome roughness={0.2} />
      </mesh>
      <mesh position={[0, 0, 0.05]}>
        <planeGeometry args={[width, height]} />
        <meshBasicMaterial map={texture} toneMapped={false} />
      </mesh>
      <mesh position={[0, 0, -0.09]} rotation={[0, Math.PI, 0]}>
        <planeGeometry args={[width - 0.1, height - 0.1]} />
        <meshStandardMaterial
          color="#060709"
          metalness={0.92}
          roughness={0.24}
        />
      </mesh>
    </group>
  );
};

const DataCard: React.FC<{
  text: string;
  sub: string;
  position: [number, number, number];
  rotation?: [number, number, number];
  width?: number;
}> = ({ text, sub, position, rotation = [0, 0, 0], width = 2.7 }) => {
  const texture = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 1024;
    canvas.height = 400;
    const c = canvas.getContext("2d")!;
    c.fillStyle = "#0c0e12";
    c.fillRect(0, 0, 1024, 400);
    c.strokeStyle = "#737882";
    c.lineWidth = 2;
    c.strokeRect(2, 2, 1020, 396);
    c.fillStyle = "#b9bfc9";
    c.font = "22px Arial";
    c.fillText(sub, 48, 70);
    c.fillStyle = "#f5f6fa";
    c.font = "49px Arial";
    c.fillText(text, 46, 166);
    c.strokeStyle = "#f2f5fc";
    c.beginPath();
    c.moveTo(48, 316);
    c.lineTo(230, 316);
    c.stroke();
    c.strokeStyle = "#32363e";
    c.beginPath();
    c.moveTo(230, 316);
    c.lineTo(970, 316);
    c.stroke();
    c.strokeStyle = "#e9edf6";
    c.beginPath();
    c.moveTo(903, 110);
    c.lineTo(951, 110);
    c.lineTo(951, 62);
    c.moveTo(951, 110);
    c.lineTo(903, 62);
    c.stroke();
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, [text, sub]);
  return (
    <group position={position} rotation={rotation}>
      <mesh>
        <boxGeometry args={[width + 0.04, width * 0.39 + 0.04, 0.06]} />
        <Chrome />
      </mesh>
      <mesh position={[0, 0, 0.035]}>
        <planeGeometry args={[width, width * 0.39]} />
        <meshBasicMaterial map={texture} toneMapped={false} />
      </mesh>
    </group>
  );
};

const OrbitSculpture: React.FC<{
  time: number;
  position?: [number, number, number];
  scale?: number;
}> = ({ time, position = [0, 0, 0], scale = 1 }) => (
  <group
    position={position}
    scale={scale}
    rotation={[0.35 + time * 0.035, time * 0.085, 0.4]}
  >
    <mesh rotation={[Math.PI / 2, 0, 0]}>
      <torusKnotGeometry args={[1.25, 0.235, 150, 20, 2, 3]} />
      <Chrome roughness={0.16} />
    </mesh>
    <Ring radius={2.15} tube={0.016} rotation={[1.2, 0.2, 0.4]} />
    <Ring radius={2.5} tube={0.012} rotation={[0.4, -0.4, 0]} dark />
  </group>
);

export const Dust: React.FC = () => {
  const pos = useMemo(() => {
    const a = new Float32Array(100 * 3);
    for (let i = 0; i < 100; i++) {
      a[i * 3] = Math.sin(i * 127.1) * 23;
      a[i * 3 + 1] = Math.cos(i * 71.3) * 10;
      a[i * 3 + 2] = -4 - (i % 23);
    }
    return a;
  }, []);
  return (
    <points>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[pos, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color="#89909d"
        size={0.018}
        transparent
        opacity={0.4}
        sizeAttenuation
      />
    </points>
  );
};

const Camera: React.FC<{ time: number }> = ({ time: t }) => {
  const { camera, scene } = useThree();
  useLayoutEffect(() => {
    let position: [number, number, number] = [0, 0, 14];
    let look: [number, number, number] = [0, 0, 0];
    if (t < 5) {
      const p = ease(t / 5);
      position = [mix(-1.8, 0.2, p), mix(1.1, 0.3, p), mix(13, 10.9, p)];
      look = [0, 0.1, 0];
    } else if (t < 12) {
      const p = ease((t - 5) / 7);
      position = [mix(-0.7, 0.45, p), mix(0.4, 0.05, p), mix(14, 11.7, p)];
      look = [0.4, 0, -1];
    } else if (t < 17.1) {
      const p = ease((t - 12) / 5.1);
      position = [mix(-1.5, 0.6, p), mix(1, 0.15, p), mix(13.6, 11.9, p)];
      look = [0, 0, -0.2];
    } else if (t < 22) {
      const p = ease((t - 17.1) / 4.9);
      position = [mix(2.8, 0.4, p), mix(1.6, 0.4, p), mix(14.5, 12.5, p)];
      look = [0.2, 0, -0.3];
    } else if (t < 30) {
      const p = ease((t - 22) / 8);
      position = [mix(-0.1, 1, p), mix(0.8, 0.1, p), mix(14, 12.4, p)];
      look = [0.2, 0, 0];
    } else {
      const p = ease((t - 30) / 5);
      position = [mix(-0.6, 0, p), mix(0.5, 0.1, p), mix(12.7, 11.8, p)];
      look = [0, 0.1, 0];
    }
    scene.environmentRotation.set(0, Math.sin(t * 0.38) * 0.24, 0);
    camera.position.set(...position);
    camera.lookAt(...look);
    camera.updateProjectionMatrix();
  }, [camera, scene, t]);
  return null;
};

export const World: React.FC<{ time: number }> = ({ time: t }) => {
  const local =
    t < 5 ? t : t < 12 ? t - 5 : t < 22 ? t - 12 : t < 30 ? t - 22 : t - 30;
  return (
    <>
      <color attach="background" args={["#020305"]} />
      <fog attach="fog" args={["#020305", 19, 45]} />
      <Lighting />
      <Camera time={t} />
      <Dust />
      {/* A black lacquer stage, deliberately abstract: no skyline or buildings. */}
      <mesh position={[0, -3.45, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[100, 100]} />
        <meshStandardMaterial
          color="#020305"
          metalness={0.1}
          roughness={0.85}
        />
      </mesh>
      {t < 5 ? (
        <>
          <Logo time={t} />
          <Ring
            position={[0, 0.3, -1.2]}
            radius={4.8}
            tube={0.018}
            rotation={[0.4, 0.4, -0.2 + t * 0.04]}
          />
          <Ring
            position={[0, 0.3, -1.4]}
            radius={5.05}
            tube={0.008}
            rotation={[0.4, 0.4, -0.2 + t * 0.04]}
          />
          <mesh position={[4, -1, -3]} rotation={[0.4, t * 0.1, 0.7]}>
            <octahedronGeometry args={[0.65, 0]} />
            <Chrome />
          </mesh>
          <mesh position={[-5, 1, -4]}>
            <sphereGeometry args={[0.25, 24, 16]} />
            <Chrome />
          </mesh>
        </>
      ) : null}
      {t >= 5 && t < 12 ? (
        <group
          position={[
            2.1 + (1 - ease(local / 1.6)) * 1.9,
            Math.sin(local * 0.6) * 0.09,
            0,
          ]}
        >
          <Panel
            site="site-index"
            width={5.9}
            position={[0.8, 0.1, 0]}
            rotation={[0.04, -0.23 + local * 0.018, 0.015]}
          />
          <Panel
            site="site-atelier"
            width={4.6}
            position={[-1.7, 1, -3.1]}
            rotation={[0.03, 0.24, -0.035]}
          />
          <Panel
            site="site-aether"
            width={4.8}
            position={[3.1, -0.55, -3.5]}
            rotation={[-0.05, -0.38, 0.04]}
          />
          <Ring
            radius={4.6}
            rotation={[0.28, 0.5, 0.2]}
            position={[0.6, 0, -2]}
            tube={0.025}
          />
          <DataCard
            text="VISIBILITÉ EN LIGNE"
            sub="01 / SOYEZ VISIBLE"
            position={[1, -2.25, 1]}
            rotation={[0, -0.15, 0]}
            width={3.5}
          />
        </group>
      ) : null}
      {t >= 12 && t < 17.1 ? (
        <group
          position={[
            0,
            -0.25 +
              Math.sin(local * 0.5) * 0.08 -
              (1 - ease(local / 1.4)) * 0.8,
            0,
          ]}
          scale={0.87 + 0.13 * ease(local / 1.4)}
        >
          <Ring
            radius={4.2}
            rotation={[0.1, 0.45, local * 0.06]}
            position={[0, 0, -3.5]}
            tube={0.045}
          />
          <Panel
            site="site-atelier"
            width={7.3}
            position={[-0.55, 0, 0]}
            rotation={[0.03, -0.12 + local * 0.025, 0]}
          />
          <Panel
            site="site-mobile"
            mobile
            width={1.65}
            position={[3.2, -0.62, 1.3]}
            rotation={[0.03, -0.28, 0.04]}
          />
          <mesh
            position={[-4.7, 1.6, -1.2]}
            rotation={[local * 0.15, 0.3, 0.5]}
          >
            <icosahedronGeometry args={[0.55, 0]} />
            <Chrome />
          </mesh>
        </group>
      ) : null}
      {t >= 17.1 && t < 22 ? (
        <group position={[0, -0.15, -0.7]}>
          <Panel
            site="site-aether"
            width={6.3}
            position={[1.45, 0.05, 0.2]}
            rotation={[0.02, -0.24 + local * 0.01, 0]}
          />
          <Panel
            site="site-index"
            width={5.8}
            position={[-3.8, -0.7, -2.2]}
            rotation={[0.05, 0.38, -0.025]}
          />
          <Ring
            radius={5.4}
            position={[0, -0.4, -2]}
            rotation={[0.3, 0.2, 0.15]}
            tube={0.024}
          />
          <DataCard
            text="TOUS ÉCRANS"
            sub="UNE IDENTITÉ. TOUS LES ÉCRANS."
            position={[2.7, -2.6, 1]}
            width={3}
          />
        </group>
      ) : null}
      {t >= 22 && t < 30 ? (
        <group>
          <OrbitSculpture
            time={local}
            position={[2.5, 0.1, -0.7]}
            scale={1.24}
          />
          <DataCard
            text={local < 4 ? "CRÉDIBILITÉ" : "CONVERSION"}
            sub={
              local < 4
                ? "01 / INSPIREZ CONFIANCE"
                : "03 / TRANSFORMEZ L’INTÉRÊT EN ACTION"
            }
            position={[2.25, 1.95, 3.2]}
            rotation={[0.02, -0.15, 0]}
            width={3.3}
          />
          <DataCard
            text={local < 4 ? "IMAGE DE MARQUE" : "CROISSANCE"}
            sub={
              local < 4
                ? "02 / AFFIRMEZ VOTRE IMAGE"
                : "04 / DONNEZ VIE À VOS AMBITIONS"
            }
            position={[3.7, -1.85, 3.2]}
            rotation={[0.02, -0.27, 0]}
            width={3.1}
          />
          <Ring
            radius={4.6}
            position={[2, 0.1, -3]}
            rotation={[0.3, 0.7, 0]}
            tube={0.014}
          />
        </group>
      ) : null}
      {t >= 30 ? (
        <>
          <Logo time={local} outro />
          <Ring
            radius={5.5}
            position={[0, 1, -2.5]}
            rotation={[0.3, -0.3, local * 0.018]}
            tube={0.022}
          />
          <Ring
            radius={5.68}
            position={[0, 1, -2.5]}
            rotation={[0.3, -0.3, local * 0.018]}
            tube={0.006}
          />
        </>
      ) : null}
    </>
  );
};
