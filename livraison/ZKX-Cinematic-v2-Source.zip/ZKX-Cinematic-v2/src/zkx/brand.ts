/** Angular ZKX mark reconstructed from the supplied film's final brand frame.
 * Coordinates use SVG orientation (y down); viewBox is 0 0 384 98.
 * Extrusion: use SVGLoader.createShapes(), center at (192,49), flip Y.
 */
export const logoBounds = { width: 384, height: 98, centerX: 192, centerY: 49 };

export const logoPaths: readonly string[] = [
  "M 9 23 L 36 0 L 144 0 L 62 73 L 131 73 L 108 98 L 0 98 L 80 23 Z",
  "M 195 0 L 237 0 L 174 51 L 238 98 L 194 98 L 133 51 Z",
  "M 237 0 L 279 0 L 384 98 L 342 98 Z",
  "M 342 0 L 384 0 L 331 50 L 310 30 Z",
  "M 288 51 L 310 72 L 279 98 L 237 98 Z",
];

export const logoPolygons: readonly (readonly [number, number][])[] = [
  [
    [9, 23],
    [36, 0],
    [144, 0],
    [62, 73],
    [131, 73],
    [108, 98],
    [0, 98],
    [80, 23],
  ],
  [
    [195, 0],
    [237, 0],
    [174, 51],
    [238, 98],
    [194, 98],
    [133, 51],
  ],
  [
    [237, 0],
    [279, 0],
    [384, 98],
    [342, 98],
  ],
  [
    [342, 0],
    [384, 0],
    [331, 50],
    [310, 30],
  ],
  [
    [288, 51],
    [310, 72],
    [279, 98],
    [237, 98],
  ],
];
