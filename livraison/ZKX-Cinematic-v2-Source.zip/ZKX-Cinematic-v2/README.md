# Nouvelle révision cinématique v2

La composition **ZKX-Vertical-Portfolio** conserve vos sites réels et propose désormais des mouvements plus amples, des traversées d’écran, des interfaces détachées et des transitions géométriques. Guide : [CINEMATIC-V2.md](CINEMATIC-V2.md).

```sh
node scripts/check-motion.mjs
node scripts/render-vertical.mjs --preview
node scripts/render-vertical.mjs
```

Export final : `out/ZKX-Portfolio-Vertical-Cinematic-v2.mp4`. La vidéo précédente est conservée séparément.

# Nouvelle publicité verticale — Portfolio réel

La composition principale est désormais **ZKX-Vertical-Portfolio** : 35 secondes en 1080×1920, avec les quatre véritables sites issus des enregistrements mobiles fournis. Documentation, provenance et commandes : [VERTICAL.md](VERTICAL.md).

```sh
npm ci --no-audit --no-fund
node scripts/render-vertical.mjs
```

La version horizontale précédente reste disponible séparément ci-dessous.

# ZKX Digital Lab — Version française

Film promotionnel de 35 secondes, 1920×1080, 30 images/s, créé avec Remotion, React Three Fiber et Three.js. Univers noir et chrome, interfaces web flottantes originales, logo extrudé et bande-son électronique originale. Tous les textes à l’écran et les maquettes web sont en français. Le logo, les noms de marques et les coordonnées conservent leur forme d’origine.

## Développement

Node 24 et Chromium sont disponibles dans cet environnement cloud.

```sh
npm ci --no-audit --no-fund
npm run dev -- --port=3000 --no-open
```

Choisir la composition **ZKX-Digital-Lab-FR** dans Remotion Studio.

## Export

Depuis la racine du dépôt :

```sh
node scripts/render.mjs
```

Fichier généré : `out/ZKX-Digital-Lab-FR-35s-1080p.mp4` (H.264, CRF 17, yuv420p, audio AAC stéréo 320 kb/s). Le script utilise `/usr/bin/chromium`, WebGL logiciel `swangle`, deux processus de rendu et une capture JPEG standard. La variable `CHROME_PATH` permet de sélectionner un autre exécutable. Le fichier de verrouillage fixe les versions des dépendances.

Le calque 3D est calculé en 1280×720 puis agrandi sous une typographie native 1920×1080 pour limiter le temps de rendu dans cet environnement sans GPU. Le fichier final est en 1920×1080. Le runner cloud peut demander son mécanisme d’autorisation d’exécution si le bac à sable bloque les appels système de Chromium.

Images clés :

```sh
node scripts/render.mjs --stills
```

Vérifications :

```sh
npm run lint
npm run build -- --out-dir=dist
ffprobe -v error -show_streams -show_format out/ZKX-Digital-Lab-FR-35s-1080p.mp4
```

## Déroulé

| Temps | Image                        | Message                               |
| ----- | ---------------------------- | ------------------------------------- |
| 00–05 | Révélation du logo chrome    | Une nouvelle dimension digitale       |
| 05–12 | Constellation de sites web   | La première impression est digitale   |
| 12–17 | Site et déclinaison mobile   | Entreprises modernes. Sites modernes. |
| 17–22 | Galerie d’interfaces         | Votre vitrine digitale                |
| 22–26 | Sculpture chrome et panneaux | Un site web inspire confiance         |
| 26–30 | Orbites et mots-clés         | Pensé pour votre croissance           |
| 30–35 | Retour au logo et contact    | Construisez votre présence digitale   |

## Fichiers à modifier

- `src/zkx/Film.tsx` : textes, rythme, transitions et audio.
- `src/zkx/World.tsx` : caméra, environnement, matériaux et objets 3D.
- `src/zkx/brand.ts` : polygones du logo reconstitués depuis la référence.
- `public/zkx/*.svg` : quatre maquettes web originales en français. Il s’agit de concepts visuels, pas de références clients.
- `public/zkx-score.wav` : bande-son originale de 35 secondes.
- `scripts/generate-score.py` : générateur audio reproductible, nécessitant Python, NumPy et SciPy. Ces dépendances ne sont pas nécessaires pour exporter la vidéo à partir du WAV fourni.

Les coordonnées sont celles de la vidéo de référence : `zkx.digital@gmail.com` et `@zkm.31`.

La version anglaise déjà livrée est conservée dans son MP4 et son archive source séparés. Les exports sont ignorés par Git. Les conditions de licence Remotion s’appliquent ; voir `LICENSE.md` et https://www.remotion.dev/license.
