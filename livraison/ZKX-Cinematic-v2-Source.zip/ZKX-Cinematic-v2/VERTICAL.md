# ZKX — Publicité verticale avec véritables sites

Composition : `ZKX-Vertical-Portfolio`, 1080×1920, 30 images/s, 1050 images (35 secondes). Elle est construite en vertical, sans recadrage d’un film horizontal. Typographie et éléments importants sont placés dans des marges de sécurité pour les interfaces sociales.

## Sources réelles intégrées

Les quatre enregistrements mobiles transmis par l’utilisateur sont la source effective des interfaces : ZKX (19-28-21), ETP (19-29-00), B.K (19-29-50) et Nero (19-30-35). Leurs pages et défilements ont été examinés. L’accès direct aux sites reste bloqué par le proxy ; aucune visite Playwright réussie n’est revendiquée.

`scripts/prepare-recordings.py` prépare cinq extraits MP4 locaux, sans audio source. Le cadrage retire la ligne d’état iOS et les commandes Safari. Les extraits portfolio retirent aussi le bandeau collant inférieur. Les proportions des interfaces sont conservées et la géométrie des écrans suit leur véritable ratio. Aucun contenu de site n’est recréé.

Le montage commence par une courte pause sur l’accueil de chaque site, puis utilise le vrai défilement, réajusté à la durée des séquences. Le manifeste `public/vertical/captures/manifest.json` indique les noms des sources, les intervalles et les cadrages. Les extraits préparés suffisent pour réexporter le film ; les fichiers originaux privés ne sont pas nécessaires.

Les smartphones, les panneaux portfolio, les trajectoires de caméra et les mots-clés 3D sont animés image par image. Les textures vidéo passent par `@remotion/media` avec lecture déterministe et mise à jour explicite du rendu 3D.

La bande-son est originale, générée par `scripts/generate-vertical-score.py`. Les sons et la musique potentiellement présents dans les enregistrements fournis sont retirés.

## Capturer les sites accessibles

```sh
node scripts/capture-sites.mjs
```

Playwright, fixé dans les dépendances, utilise le Chromium fourni par le système et le proxy cloud hérité. Il charge réellement les quatre sites, relève leurs titres/sections et capture les pages mobiles à 540×1170. Les captures longues sont conservées et réduites uniformément seulement si leur hauteur dépasse 8192 pixels. Le manifeste documente les erreurs et ressources non chargées. Vérifier les captures avant rendu et faire autoriser les domaines des ressources supplémentaires uniquement si nécessaire. Ne pas ignorer les erreurs TLS ou inventer les sections manquantes.

## Variante : utiliser des images fixes fournies

Extraire les fichiers mobiles d’un ZIP dans un dossier. Nommer les fichiers `zkx.png`, `etp.png`, `bk.png`, `nero.png` (ou `.jpg`). Préférer une capture longue de ZKX contenant accueil, présentation, services et réalisations.

```sh
python scripts/import-captures.py /chemin/vers/les/captures
```

Ce script d’import d’images constitue une variante de préparation ; le film actuel utilise les enregistrements MP4. Les originaux sont conservés et les proportions respectées. Une capture horizontale est signalée pour éviter un affichage déformé sur le smartphone. Ne pas présenter un défilement de sections qui ne sont pas fournies.

## Vérifier et exporter

```sh
npm ci --no-audit --no-fund
npm run lint
npm run build -- --out-dir=dist
node scripts/render-vertical.mjs --intro
node scripts/render-vertical.mjs --stills
node scripts/render-vertical.mjs
```

`--intro` vérifie les images de l’introduction et de la conclusion indépendamment des captures. Les autres modes refusent de produire un film sans les cinq extraits MP4 locaux réels.

Sortie finale attendue : `out/ZKX-Portfolio-Vertical-35s.mp4`, H.264, CRF 17, audio AAC stéréo. Chromium utilise le moteur logiciel swangle, deux workers et la capture JPEG standard. Dans le cloud, utiliser le mécanisme d’exécution autorisé si le bac à sable bloque Chromium. Le fichier et les titres sont en 1080×1920. Le calque 3D utilise un tampon de 720×1280 agrandi sous les textes ; les vidéos des écrans proviennent d’enregistrements de largeur 512 pixels. Bloom et profondeur de champ sont calculés à résolution réduite pour le rendu logiciel.

## Construction

- Remotion : timeline, synchronisation et export.
- React Three Fiber + Three.js : caméra, géométrie du logo, matériaux et textures réelles.
- Drei : smartphones arrondis et typographie 3D.
- @react-three/postprocessing + postprocessing : bloom discret et profondeur de champ.
- Playwright : captures et inspection des véritables sites.

Toutes les animations dépendent du numéro d’image. La nouvelle bande-son procédurale est originale et ses transitions suivent les séquences ; aucune musique commerciale de la référence n’est reprise.

Déroulé : introduction 0–5 s, ZKX 5–15 s, ETP/B.K/Nero 15–26 s, retour ZKX et impact 26–31 s, conclusion 31–35 s. Les trois projets sont explicitement légendés comme réalisations du portfolio.
