import { bundle } from "@remotion/bundler";
import {
  selectComposition,
  renderMedia,
  renderStill,
} from "@remotion/renderer";
import path from "node:path";
import { mkdir } from "node:fs/promises";

const serveUrl = await bundle({
  entryPoint: path.resolve("src/index.ts"),
  enableCaching: true,
});
const browserExecutable = process.env.CHROME_PATH || "/usr/bin/chromium";
const chromiumOptions = { gl: "swangle" };
const composition = await selectComposition({
  serveUrl,
  id: "ZKX-Digital-Lab-FR",
  browserExecutable,
  chromiumOptions,
});
await mkdir("out", { recursive: true });
if (process.argv.includes("--stills")) {
  const frames = [90, 240, 435, 585, 720, 840, 990];
  // Limit simultaneous software WebGL contexts.
  for (let i = 0; i < frames.length; i += 2) {
    await Promise.all(
      frames.slice(i, i + 2).map((frame) =>
        renderStill({
          serveUrl,
          composition,
          frame,
          output: `out/review-fr-${frame}.png`,
          browserExecutable,
          chromiumOptions,
          imageFormat: "png",
        }),
      ),
    );
    console.log(
      `Reviewed through ${frames[Math.min(i + 1, frames.length - 1)]}`,
    );
  }
} else {
  let previous = -1;
  await renderMedia({
    serveUrl,
    composition,
    codec: "h264",
    crf: 17,
    pixelFormat: "yuv420p",
    audioCodec: "aac",
    audioBitrate: "320k",
    outputLocation: "out/ZKX-Digital-Lab-FR-35s-1080p.mp4",
    browserExecutable,
    chromiumOptions,
    concurrency: 2,
    disableSharedMemoryCapture: true,
    imageFormat: "jpeg",
    jpegQuality: 95,
    onStart: () => console.log("Rendering 1050 frames"),
    onProgress: ({ progress }) => {
      const percent = Math.floor(progress * 100);
      if (percent >= previous + 1) {
        console.log(`Render ${percent}%`);
        previous = percent;
      }
    },
  });
  console.log("Finished: out/ZKX-Digital-Lab-FR-35s-1080p.mp4");
}
