"""Original 35-second ZKX chrome/electronic score. Deterministic procedural synthesis."""
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io.wavfile import write
from pathlib import Path

SR=48000
D=35
N=SR*D
rng=np.random.default_rng(31026)
dry=np.zeros((N,2),np.float64)
wet=np.zeros_like(dry)

def hz(midi): return 440*2**((midi-69)/12)
def filt(x,f,kind='lowpass',order=3): return sosfilt(butter(order,f,kind,fs=SR,output='sos'),x)
def place(x,start,gain=1,pan=0,send=.15):
    n=min(len(x),N-int(start*SR))
    if n<=0:return
    i=int(start*SR)
    x=x[:n]
    if x.ndim==1:
        p=(pan+1)*np.pi/4
        x=np.stack([x*np.cos(p),x*np.sin(p)],axis=1)
    dry[i:i+n]+=x*gain
    wet[i:i+n]+=x*gain*send

def pad(start,dur,notes,level=.055):
    t=np.arange(int((dur+1.7)*SR))/SR
    env=np.minimum(t/1.35,1)*np.minimum(np.maximum((dur+1.7-t)/2.3,0),1)
    env=np.sin(env*np.pi/2)**2
    out=np.zeros((len(t),2))
    for k,n in enumerate(notes):
        f=hz(n)
        for ch in range(2):
            detune=1+(.0009 if ch==0 else -.0009)
            y=np.sin(2*np.pi*f*detune*t+.4*k)
            y+=.25*np.sin(2*np.pi*f*2.002*t+k)
            y+=.10*np.sin(2*np.pi*f*3.001*t)
            out[:,ch]+=y/len(notes)
    out*=env[:,None]*(.95+.05*np.sin(t[:,None]*.8))
    place(out,start,level,send=.7)

# Dark spacious bed; chord shifts follow the film's chapter boundaries.
for start,dur,notes,lev in [
 (0,5,[38,50,57,60,64],.12),
 (4.2,7.5,[34,50,53,57,60],.105),
 (11.4,5.5,[38,53,57,60,64],.125),
 (16.7,5.8,[34,50,53,57,62],.115),
 (21.5,4.8,[43,50,57,58,62],.125),
 (25.8,4.8,[45,52,57,62,64],.12),
 (29.5,5.5,[38,50,57,60,64],.14),
]: pad(start,dur,notes,lev)

# Understated analogue sequencer, opened up as the websites appear.
step=.3
sequence=[62,69,74,76,69,65,72,69]
for j,tm in enumerate(np.arange(5.1,29.7,step)):
    t=np.arange(int(.68*SR))/SR
    note=sequence[j%len(sequence)]
    f=hz(note)
    tone=np.sin(2*np.pi*f*t)+.20*np.sin(2*np.pi*2*f*t)+.04*np.sin(2*np.pi*3*f*t)
    env=(1-np.exp(-t/.007))*np.exp(-t/.115)
    amp=.024 if tm<12 else (.040 if tm<22 else .045)
    if j%4==0:amp*=1.3
    place(tone*env,tm,amp,pan=.5*np.sin(j*1.4),send=.8)
    place(tone*env,tm+.225,amp*.27,pan=-.55*np.sin(j*1.4),send=.8)

# Rounded sub/bass pulses with a gentle saturated second harmonic.
for j,tm in enumerate(np.arange(5.1,29.7,.6)):
    root=38 if tm<12 else (38 if tm<17 else (34 if tm<22 else (43 if tm<26 else 45)))
    t=np.arange(int(.62*SR))/SR
    f=hz(root)
    env=(1-np.exp(-t/.012))*np.exp(-t/.24)
    y=(np.sin(2*np.pi*f*t)+.20*np.sin(2*np.pi*f*2*t))*env
    place(y,tm,.075 if tm<12 else .11,send=.04)

# Soft, deep cinematic percussion, no aggressive snare.
for j,tm in enumerate(np.arange(12.0,29.8,.6)):
    if j%4==3:continue
    t=np.arange(int(.65*SR))/SR
    f=45+75*np.exp(-t/0.028)
    phase=np.cumsum(f)*2*np.pi/SR
    y=np.sin(phase)*np.exp(-t/.14)*(1-np.exp(-t/.002))
    place(y,tm,.19 if tm<22 else .23,send=.035)
for j,tm in enumerate(np.arange(12.3,29.8,.6)):
    t=np.arange(int(.11*SR))/SR
    y=filt(rng.normal(0,1,len(t)),4500,'highpass')
    y=filt(y,8000)*np.exp(-t/.018)*(1-np.exp(-t/.001))
    place(y,tm,.012 if j%2 else .018,pan=.25*(-1)**j,send=.26)

# Sweeping airy transitions and low chrome impacts synchronized to scene cuts.
for k,end in enumerate([5,15,18.67,22.33,26,31]):
    dur=1.45 if end!=31 else 1.7
    t=np.arange(int(dur*SR))/SR
    n=filt(rng.normal(0,1,len(t)),2200)
    n=filt(n,350,'highpass')
    env=(t/dur)**2*np.sin(np.pi*np.clip(t/dur,0,1))**.4
    place(n*env,end-dur,.055,pan=-.1,send=.65)
    t=np.arange(int(2.8*SR))/SR
    phase=2*np.pi*(35*t+4*(1-np.exp(-t*4)))
    low=np.sin(phase)*np.exp(-t/.7)*(1-np.exp(-t/.005))
    metal=np.sin(2*np.pi*740*t)*np.exp(-t/.12)+.35*np.sin(2*np.pi*1122*t)*np.exp(-t/.21)
    place(low,end,.24,send=.10)
    place(metal,end,.021,pan=.2,send=.8)

# Spacious opening and final logo shimmer.
for start,amp in [(0.25,.16),(31,.18)]:
    t=np.arange(int(4.3*SR))/SR
    y=np.zeros_like(t)
    for i,n in enumerate([74,81,86,88]):
        y+=np.sin(2*np.pi*hz(n)*t+.3*i)*np.exp(-t/(1.6+i*.2))*.25
    env=(1-np.exp(-t/.035))
    place(y*env,start,amp,pan=-.15,send=.9)

# Synthetic diffuse stereo room response. Low-pass the reverb for soft metallic depth.
for ch in range(2):
    impulse=np.zeros(int(2.9*SR))
    count=180
    idx=np.sort(rng.integers(int(.035*SR),len(impulse),count))
    impulse[idx]=rng.normal(0,1,count)*np.exp(-idx/SR/0.70)*.075
    rev=fftconvolve(wet[:,ch],impulse)[:N]
    dry[:,ch]+=filt(rev,4200)

# Broad stereo delays create reflections in the dark environment.
for sec,g in [(.375,.10),(.75,.065), (1.125,.025)]:
    d=int(sec*SR)
    dry[d:,0]+=wet[:-d,1]*g
    dry[d:,1]+=wet[:-d,0]*g

# Remove infrasonic content, soft limiting, and intentional fade to black.
for ch in range(2):dry[:,ch]=filt(dry[:,ch],26,'highpass')
t=np.arange(N)/SR
env=np.minimum(t/.12,1)*np.minimum(np.clip((35-t)/1.4,0,1),1)
dry*=env[:,None]
dry=np.tanh(dry*1.18)
peak=np.max(np.abs(dry))
dry*=.82/peak
out=Path(__file__).resolve().parents[1] / 'public' / 'vertical' / 'score.wav'
write(out,SR,(dry*32767).astype(np.int16))
print(f'{out}: {D}s stereo 48kHz, peak={20*np.log10(np.max(np.abs(dry))):.2f}dBFS, RMS={20*np.log10(np.sqrt(np.mean(dry**2))):.2f}dBFS')
