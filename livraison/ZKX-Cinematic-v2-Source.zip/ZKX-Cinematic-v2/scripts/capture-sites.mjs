import { chromium } from "playwright";
import { mkdir, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";

const sites = [
  { slug: "zkx", url: "https://zkx.digital-lab-9d1.workers.dev/" },
  { slug: "etp", url: "https://etp-peinture.netlify.app/" },
  { slug: "bk", url: "https://bk-multiservices31.zakmendes1.workers.dev/" },
  { slug: "nero", url: "https://nero-toulouse.zakmendes1.workers.dev/" },
];
const proxyUrl = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  headless: true,
  proxy: proxyUrl ? { server: proxyUrl } : undefined,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
await mkdir("public/vertical/captures", { recursive: true });
const results = [];
try {
  for (const site of sites) {
    const context = await browser.newContext({
      viewport: { width: 540, height: 1170 },
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: true,
      colorScheme: "dark",
      reducedMotion: "reduce",
    });
    const page = await context.newPage();
    const failures = [];
    page.on("requestfailed", (r) =>
      failures.push({
        host: new URL(r.url()).hostname,
        error: r.failure()?.errorText,
      }),
    );
    try {
      const response = await page.goto(site.url, {
        waitUntil: "networkidle",
        timeout: 45000,
      });
      if (!response?.ok()) throw new Error(`HTTP ${response?.status()}`);
      await page.evaluate(async () => {
        await document.fonts.ready;
      });
      // Visit the complete page to load actual lazy-loaded content before the capture.
      const height = await page.evaluate(
        () => document.documentElement.scrollHeight,
      );
      for (let y = 0; y < height; y += 700) {
        await page.evaluate((v) => scrollTo(0, v), y);
        await page.waitForTimeout(150);
      }
      await page.evaluate(() => scrollTo(0, 0));
      await page.waitForTimeout(400);
      const info = await page.evaluate(() => ({
        title: document.title,
        headings: [...document.querySelectorAll("h1,h2,h3")].map((e) =>
          e.textContent?.trim(),
        ),
        sections: [...document.querySelectorAll("section[id]")].map((e) => ({
          id: e.id,
          y: e.getBoundingClientRect().top + scrollY,
        })),
        width: innerWidth,
        height: document.documentElement.scrollHeight,
      }));
      await page.screenshot({
        path: `public/vertical/captures/${site.slug}-full.png`,
        fullPage: true,
        animations: "disabled",
      });
      await page.screenshot({
        path: `public/vertical/captures/${site.slug}-home.png`,
        animations: "disabled",
      });
      // Uniform reduction only if needed to fit software WebGL's texture limit. No stretching.
      execFileSync("python", [
        "-c",
        `from PIL import Image\np='public/vertical/captures/${site.slug}-full.png'\nim=Image.open(p)\nif im.height>8192: im=im.resize((round(im.width*8192/im.height),8192),Image.Resampling.LANCZOS)\nim.save('public/vertical/captures/${site.slug}.png')`,
      ]);
      results.push({ ...site, ...info, failures, status: "captured" });
      console.log(`${site.slug}: ${info.title}; ${info.headings.join(" | ")}`);
    } catch (error) {
      results.push({
        ...site,
        status: "failed",
        error: String(error),
        failures,
      });
      console.error(`${site.slug}: ${String(error)}`);
    }
    await context.close();
  }
} finally {
  await browser.close();
}
await writeFile(
  "public/vertical/captures/manifest.json",
  JSON.stringify(
    {
      capturedAt: new Date().toISOString(),
      viewport: { width: 540, height: 1170 },
      sites: results,
    },
    null,
    2,
  ),
);
if (results.some((s) => s.status !== "captured")) process.exitCode = 1;
