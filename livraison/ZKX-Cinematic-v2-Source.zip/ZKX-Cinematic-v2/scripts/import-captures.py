"""Import original user-provided mobile screenshots; never recreate their content.
Usage: python scripts/import-captures.py /path/to/extracted/screenshots
Expected names: zkx.png, etp.png, bk.png, nero.png (JPG/JPEG also supported).
"""
import sys,json,shutil
from pathlib import Path
from PIL import Image
source=Path(sys.argv[1])
root=Path(__file__).resolve().parents[1]
out=root/'public'/'vertical'/'captures'
out.mkdir(parents=True,exist_ok=True)
records=[]
for slug in ['zkx','etp','bk','nero']:
    candidates=[p for p in source.iterdir() if p.stem.lower()==slug and p.suffix.lower() in ['.png','.jpg','.jpeg']]
    if len(candidates)!=1:
        raise SystemExit(f'Un fichier unique est requis pour {slug}: PNG, JPG ou JPEG.')
    original=candidates[0]
    image=Image.open(original).convert('RGB')
    if image.height/image.width<1.7:
        raise SystemExit(f'{slug}: cette capture est horizontale. Une vue mobile est requise pour éviter de déformer ou de couper le site dans le smartphone.')
    (out/'originaux').mkdir(exist_ok=True)
    shutil.copy2(original,out/'originaux'/original.name)
    width,height=image.size
    if image.height>8192:image=image.resize((round(image.width*8192/image.height),8192),Image.Resampling.LANCZOS)
    image.save(out/(slug+'.png'))
    records.append({'slug':slug,'source':'capture fournie par utilisateur','original':original.name,'width':width,'height':height})
(out/'manifest.json').write_text(json.dumps({'source':'user screenshots','sites':records},indent=2,ensure_ascii=False))
print('Quatre captures réelles importées, proportions conservées.')
