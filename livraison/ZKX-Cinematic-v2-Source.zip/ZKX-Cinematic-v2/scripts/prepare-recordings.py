"""Prepare genuine mobile screen recordings supplied by the user.
Only browser/system chrome is cropped. Content is never redesigned or stretched.
Usage: python scripts/prepare-recordings.py <zkx.mp4> <etp.mp4> <bk.mp4> <nero.mp4>
"""
import sys,subprocess,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'public/vertical/captures';out.mkdir(parents=True,exist_ok=True)
files=dict(zip(['zkx','etp','bk','nero'],map(Path,sys.argv[1:])))
if len(files)!=4:raise SystemExit('Four source recordings are required.')
# Remove iOS status row (56px) and Safari toolbar. Keep site navigation and sticky site buttons.

plans=[('zkx-main','zkx',10,17.6,1),('etp','etp',110/30,6.5,.85),('bk','bk',110/30,7.5,.85),('nero','nero',110/30,6.5,.85),('zkx-impact','zkx',5,5.6,1.2)]
records=[]
for name,slug,duration,end,hold in plans:
 source=files[slug];start=.1;move=duration-hold
 height=928 if slug=="zkx" else 824
 crop=f"crop=512:{height}:0:56,setsar=1"
 graph=f'[0:v]{crop},trim=start={start}:end={end},setpts=(PTS-STARTPTS)*{move/(end-start)},fps=30,tpad=start_mode=clone:start_duration={hold}:stop_mode=clone:stop_duration=0.2,trim=duration={duration},setpts=PTS-STARTPTS,format=yuv420p[v]'
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(source),'-filter_complex',graph,'-map','[v]','-an','-c:v','libx264','-preset','fast','-crf','15','-frames:v',str(round(duration*30)),'-color_range','tv','-movflags','+faststart',str(out/(name+'.mp4'))],check=True)
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(out/(name+'.mp4')),'-frames:v','1',str(out/(name+'.png'))],check=True)
 records.append({'asset':name,'source':source.name,'site':slug,'origin':'Enregistrement fourni par utilisateur','duration':duration,'sourceExcerpt':[start,end],'openingHold':hold,'crop':{'x':0,'y':56,'width':512,'height':height},'audio':'removed'})
 print('Préparé :',name,flush=True)
(out/'manifest.json').write_text(json.dumps({'source':'genuine user mobile screen recordings','assets':records},ensure_ascii=False,indent=2))
