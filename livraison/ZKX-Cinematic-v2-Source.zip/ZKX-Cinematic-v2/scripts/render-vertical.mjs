import { bundle } from "@remotion/bundler";
import {
  selectComposition,
  renderMedia,
  renderStill,
} from "@remotion/renderer";
import { access, mkdir } from "node:fs/promises";
import path from "node:path";
const intro = process.argv.includes("--intro");
const preview = process.argv.includes("--preview");
const inputProps = { preview };
const rangeArg = process.argv.find((a) => a.startsWith("--range="));
const frameRange = rangeArg
  ? rangeArg.split("=")[1].split(",").map(Number)
  : undefined;
const framesArg = process.argv.find((a) => a.startsWith("--frames="));
const reviewFrames = framesArg
  ? framesArg.split("=")[1].split(",").map(Number)
  : [90, 205, 270, 320, 370, 495, 600, 720, 840, 980];
if (!intro) {
  for (const slug of ["zkx-main", "etp", "bk", "nero", "zkx-impact"]) {
    try {
      await access(`public/vertical/captures/${slug}.mp4`);
    } catch {
      throw new Error(
        `Capture réelle manquante : ${slug}. Fournir une capture ou exécuter scripts/capture-sites.mjs après autorisation réseau.`,
      );
    }
  }
}
await mkdir("out", { recursive: true });
const serveUrl = await bundle({
  entryPoint: path.resolve("src/index.ts"),
  enableCaching: true,
});
const browserExecutable = process.env.CHROME_PATH || "/usr/bin/chromium";
const chromiumOptions = { gl: "swangle" };
const composition = await selectComposition({
  serveUrl,
  id: "ZKX-Vertical-Portfolio",
  inputProps,
  browserExecutable,
  chromiumOptions,
});
if (process.argv.includes("--stills") || intro || framesArg) {
  for (const frame of intro ? [90, 990] : reviewFrames) {
    await renderStill({
      serveUrl,
      composition,
      frame,
      browserExecutable,
      chromiumOptions,
      inputProps,
      scale: preview ? 0.5 : 1,
      output: `out/cinematic-v2-${frame}.png`,
      imageFormat: "png",
    });
    console.log(`Image vérifiée : ${frame}`);
  }
} else {
  let last = -1;
  const smoke = process.argv.includes("--smoke");
  await renderMedia({
    serveUrl,
    composition,
    inputProps,
    scale: preview ? 0.5 : 1,
    browserExecutable,
    chromiumOptions,
    outputLocation:
      smoke || frameRange
        ? "out/ZKX-Cinematic-v2-Test.mp4"
        : preview
          ? "out/ZKX-Cinematic-v2-Preview.mp4"
          : "out/ZKX-Portfolio-Vertical-Cinematic-v2.mp4",
    frameRange: frameRange ?? (smoke ? [150, 179] : undefined),
    codec: "h264",
    crf: 17,
    pixelFormat: "yuv420p",
    audioCodec: "aac",
    audioBitrate: "256k",
    concurrency: 2,
    disableSharedMemoryCapture: true,
    imageFormat: "jpeg",
    jpegQuality: 95,
    onProgress: ({ progress }) => {
      const p = Math.floor(progress * 100);
      if (p >= last + 5) {
        console.log(`Rendu : ${p} %`);
        last = p;
      }
    },
  });
  console.log(
    smoke
      ? "Test terminé : out/ZKX-Cinematic-v2-Test.mp4"
      : "Export cinématique v2 terminé",
  );
}
