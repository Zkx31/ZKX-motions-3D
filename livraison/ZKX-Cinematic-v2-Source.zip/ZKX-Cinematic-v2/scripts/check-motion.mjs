import ts from "typescript";
import { readFile } from "node:fs/promises";
import assert from "node:assert/strict";
const source = await readFile("src/vertical/motion.ts", "utf8");
const js = ts.transpileModule(source, {
  compilerOptions: {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.ES2022,
  },
}).outputText;
const { cameraAt, deviceAt, transitionAt, focusAt } = await import(
  "data:text/javascript;base64," + Buffer.from(js).toString("base64")
);
let near = Infinity,
  far = 0,
  totalTravel = 0,
  previous;
for (let f = 0; f < 1050; f++) {
  assert(Number.isFinite(focusAt(f)) && focusAt(f) >= 0 && focusAt(f) <= 1);
  const c = cameraAt(f),
    p = transitionAt(f);
  assert(
    [...c.position, ...c.target, p.strength, p.flash].every(Number.isFinite),
  );
  assert(
    Math.hypot(...c.position.map((v, i) => v - c.target[i])) > 0.05,
    "Degenerate camera target",
  );
  assert(p.strength >= 0 && p.strength <= 1);
  assert.deepEqual(
    c,
    cameraAt(f),
    "Animation state must not depend on evaluation order",
  );
  if (previous)
    totalTravel += Math.hypot(...c.position.map((v, i) => v - previous[i]));
  previous = c.position;
  near = Math.min(near, c.position[2]);
  far = Math.max(far, c.position[2]);
  const slug =
    f < 150 || f >= 930
      ? null
      : f < 450
        ? "zkx-main"
        : f < 560
          ? "etp"
          : f < 670
            ? "bk"
            : f < 780
              ? "nero"
              : "zkx-impact";
  if (slug) {
    const d = deviceAt(slug, f);
    assert(
      [...d.position, ...d.rotation, d.scale, d.assembly].every(
        Number.isFinite,
      ),
    );
    assert(d.scale > 0 && d.scale < 1.1);
    assert(d.assembly >= 0 && d.assembly <= 1);
  }
}
for (const f of [149, 449, 669, 929])
  assert(
    cameraAt(f).position[2] < 0.4,
    "Screen traversal must reach the near plane",
  );
assert.deepEqual(
  cameraAt(559),
  cameraAt(560),
  "The metallic flip must preserve the camera",
);
assert.deepEqual(
  deviceAt("etp", 559).position,
  deviceAt("bk", 560).position,
  "Flip silhouette position must match",
);
assert(Math.abs(Math.cos(deviceAt("etp", 559).rotation[1])) < 1e-8);
assert(Math.abs(Math.cos(deviceAt("bk", 560).rotation[1])) < 1e-8);
assert(
  totalTravel > 80,
  "Camera movement must materially exceed the former slow drift",
);
assert.equal(transitionAt(0).flash, 0);
console.log(
  `1050 frames checked: deterministic finite poses, exact flip continuity, 4 near-plane traversals. Camera travel ${totalTravel.toFixed(1)} units, Z range ${near.toFixed(2)}–${far.toFixed(1)}.`,
);
