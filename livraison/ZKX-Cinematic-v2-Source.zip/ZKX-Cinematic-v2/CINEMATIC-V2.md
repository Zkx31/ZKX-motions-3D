# ZKX — Révision cinématique v2

Cette révision améliore le projet existant et conserve les quatre interfaces réelles, les médias préparés, le logo reconstruit et la bande-son originale. La précédente vidéo `out/ZKX-Portfolio-Vertical-35s.mp4` reste intacte.

## Changements de mise en scène

- Logo : assemblage chromé progressif avec décalage des fragments, rotations 3D, caméra orbitale et accélération dans le logo.
- ZKX : smartphone assemblé depuis la profondeur, trajectoires latérales, travellings avant/arrière et rotations coordonnées. Des captures réelles du portfolio et des services se détachent du téléphone puis se regroupent sur l’axe de la caméra.
- ETP : arrivée depuis la profondeur, rotation et phase de lecture, puis mise sur la tranche.
- B.K : retournement de 180° par deux faces successives vues sur la tranche, avec continuité de position/caméra et volet métallique. L’objet précédent sert à révéler le suivant.
- Nero : passage rapproché à travers l’interface B.K et recul cinématographique révélant le nouveau panneau.
- Impact : trois interfaces du portfolio s’éloignent derrière le téléphone ZKX. Les mots-clés extrudés entrent depuis la profondeur.
- Conclusion : nouvelle traversée rapprochée, recul/orbite et réassemblage du logo.
- Décor : portiques chromés à plusieurs profondeurs, fragments métalliques discrets, variation de l’environnement de réflexion et lumière mobile. Aucun décor urbain.

Les fondus noirs entre projets ont été retirés. Le noir est réservé au début et à la fin. Les transitions combinent géométrie, caméra, bref éclat lumineux et flou spatial directionnel/zoom. Ce shader ne prétend pas produire un flou temporel à partir de vecteurs de mouvement.

Les moments de lecture sont séparés des passages rapides ; titres et légendes s’effacent pendant les traversées pour ne pas encombrer les interfaces.

## Contrôle déterministe

`src/vertical/motion.ts` contient les poses et trajectoires indexées en frames. Les courbes sont évaluées indépendamment de l’ordre de calcul, sans horloge d’animation temps réel. Le callback vidéo conserve le rôle de mise à jour de texture et de rendu ; `performance.now()` n’est pas utilisé pour calculer les trajectoires.

```sh
npm ci --no-audit --no-fund
npm run lint
node scripts/check-motion.mjs
npm run build -- --out-dir=dist
```

La mise au point suit également le sujet en fonction de la caméra et de sa profondeur, avec un transfert progressif de Nero vers ZKX. Le contrôle de mouvement vérifie les 1050 frames, les valeurs finies, les cibles caméra, les échelles et assemblages, la continuité du flip et les quatre passages au voisinage des écrans.

## Prévisualiser

```sh
node scripts/render-vertical.mjs --preview
node scripts/render-vertical.mjs --preview --range=760,825
node scripts/render-vertical.mjs --preview --stills
node scripts/render-vertical.mjs --preview --frames=140,148,152,170,430,448,452,550,559,565,660,668,672,785,920,929,935,960
```

Le MP4 de prévisualisation est `out/ZKX-Cinematic-v2-Preview.mp4` en 540×960, 30 images/s, 35 secondes. Son tampon 3D est réduit pour vérifier la mise en scène rapidement.

## Export final

```sh
node scripts/render-vertical.mjs
```

Sortie : `out/ZKX-Portfolio-Vertical-Cinematic-v2.mp4`, 1080×1920, 30 images/s, 35 secondes (1050 images), H.264 et audio AAC stéréo. Les titres sont natifs 1080×1920 ; le tampon 3D est en 720×1280 avec FXAA. Les enregistrements des sites ont une largeur de 512 pixels, sans interface inventée.

Le rendu logiciel utilise Chromium `/usr/bin/chromium`, swangle, deux workers et une capture JPEG standard. Employer le mécanisme d’exécution autorisé du runner si le bac à sable bloque Chromium. Les instructions de provenance des médias restent dans `VERTICAL.md`.

## Ressources techniques

Les README des neuf dépôts cités ont été consultés. La version R3F 9 correspond à React 19 ; les versions déjà verrouillées de Drei et Postprocessing conviennent. Remotion reste responsable des frames et de l’encodage, Drei des maillages arrondis et textes 3D, Postprocessing des effets.

Les trajectoires nécessaires sont exprimées directement en courbes de poses Three.js/Remotion : aucun paquet Theatre.js ou GSAP supplémentaire n’est requis et aucune boucle d’animation de ces bibliothèques n’est introduite. Le modèle de smartphone procédural existant est réutilisé ; aucun nouveau GLB n’a été téléchargé. Playwright reste disponible mais les captures supplémentaires sont extraites des enregistrements authentiques déjà fournis.
